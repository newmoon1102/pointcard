//
//  Global.h
//
//  Created by oa-center on 2015/01/16.
//  Copyright (c) 2015 oa-center company. All rights reserved.
//

#ifndef SetaBase_Global_h
#define SetaBase_Global_h

//Some useful macro
#import "Macro.h"

//Define all key here
#define kBaseURL @""
#define IPAD_XIB_POSTFIX @"~iPad"

//Common class
#import "Constants.h"
#import "Util.h"
#import "GCDispatch.h"
#import "ePOS2.h"

#import "APIClient.h"
#import "AudioPlayerManager.h"

#endif
