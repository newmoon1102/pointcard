//
//  Restaurants
//
//  Created by oa-center on 2015/01/16.
//  Copyright (c) 2015 oa-center company. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface AudioPlayerManager : NSObject <AVAudioPlayerDelegate>
{
}
@property (nonatomic, retain) AVAudioPlayer *audioPlayer;
@property (nonatomic, retain) NSTimer* playbackTimer;
+ (AudioPlayerManager*) shareAudioManager;
-(void) playEffectAudio:(NSString*)fileName;
@end
