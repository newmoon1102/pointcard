//
//  Restaurants
//
//  Created by oa-center on 2015/01/16.
//  Copyright (c) 2015 oa-center company. All rights reserved.
//

#import "AudioPlayerManager.h"

@implementation AudioPlayerManager
@synthesize audioPlayer = _audioPlayer;
@synthesize playbackTimer = _playbackTimer;
static AudioPlayerManager *audioManager_ = nil;
+ (AudioPlayerManager*) shareAudioManager {
    if (audioManager_) return audioManager_;
    @synchronized(self) {
        if (!audioManager_) {
            audioManager_ = [[AudioPlayerManager alloc] init];
        }
    }
    return audioManager_;
}

- (id)init
{
    self = [super init];
    if (self) {
        // Do something.
//        self.audioPlayer = [[AVAudioPlayer alloc] init];
    }
    return self;
}

- (void)dealloc
{
    [_audioPlayer release];
    _audioPlayer = nil;
    [super dealloc];
}

-(void) playEffectAudio:(NSString*)fileName {
    [[AVAudioSession sharedInstance] setCategory: AVAudioSessionCategoryPlayback error: nil];
    // Play sound.
    NSURL *url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@", [[NSBundle mainBundle] resourcePath],fileName]];
    NSError *error;
    // Play audio
    AVAudioPlayer* newAudioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
    self.audioPlayer = newAudioPlayer;
    self.audioPlayer.delegate = self;
    self.audioPlayer.numberOfLoops = 0;
    if (self.audioPlayer) [self.audioPlayer play];
    else  NSLog(@"Audio Error: %@ at URL: %@",[error description],url);
    [newAudioPlayer release];
}

#pragma mark -
#pragma mark AVAudioPlayer delegate

- (void) audioPlayerDidFinishPlaying: (AVAudioPlayer *) appSoundPlayer successfully: (BOOL) flag {
    // Change view back

}

- (void) audioPlayerBeginInterruption: player {

}

- (void) audioPlayerEndInterruption: player {
    // NSLog(@"End Interruption");
}
@end
