//
//  ConfirmViewController.m
//  WP_PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/02.
//  Copyright © 2016年 OA-Center Company. All rights reserved.
//

#import "ConfirmViewController.h"
#import "Constants.h"
#import "RegisterViewController.h"
#import "InfoViewController.h"

@interface ConfirmViewController ()
@property (strong, nonatomic) IBOutlet UILabel *lbRestaurantsName;
@property (strong, nonatomic) IBOutlet UILabel *lbFirstNameKanji;
@property (strong, nonatomic) IBOutlet UILabel *lbLastNameKanji;
@property (strong, nonatomic) IBOutlet UILabel *lbFirstNameHiragana;
@property (strong, nonatomic) IBOutlet UILabel *lbLastNameHiragana;
@property (strong, nonatomic) IBOutlet UILabel *lbNameYobidashi;
@property (strong, nonatomic) IBOutlet UILabel *lbFirstPostNumber;
@property (strong, nonatomic) IBOutlet UILabel *lbLastPostNumber;
@property (strong, nonatomic) IBOutlet UILabel *lbFirstPhoneNumber;
@property (strong, nonatomic) IBOutlet UILabel *lbMidPhoneNumber;
@property (strong, nonatomic) IBOutlet UILabel *lbLastPhoneNumber;
@property (strong, nonatomic) IBOutlet UILabel *lbFirstMobileNumber;
@property (strong, nonatomic) IBOutlet UILabel *lbMidMobileNumber;
@property (strong, nonatomic) IBOutlet UILabel *lbLastMobileNumber;
@property (strong, nonatomic) IBOutlet UILabel *lbYearBirthday;
@property (strong, nonatomic) IBOutlet UILabel *lbMonthBirthday;
@property (strong, nonatomic) IBOutlet UILabel *lbDayBirthday;
@property (strong, nonatomic) IBOutlet UILabel *lbGender;
@property (strong, nonatomic) IBOutlet UILabel *lbFirstEmail;
@property (strong, nonatomic) IBOutlet UILabel *lbLastEmail;
@property (strong, nonatomic) IBOutlet UILabel *lbPassword;
@property (strong, nonatomic) IBOutlet UILabel *lbMagazineEmailNotifi;
@property (strong, nonatomic) IBOutlet UILabel *lbDirectEmailNotifi;
@property (strong, nonatomic) IBOutlet UILabel *lbCharacterSpecialEmail;

@property (strong, nonatomic) IBOutlet UITextView *txtViewAddressDetail;

@property (strong, nonatomic) IBOutlet UIImageView *imgStarValidateZipCode;
@property (strong, nonatomic) IBOutlet UIImageView *imgStarValidateAddress;
@property (strong, nonatomic) IBOutlet UIImageView *imgStarValidatePhone;
@property (strong, nonatomic) IBOutlet UIImageView *imgStarValidateBirthday;

@end

@implementation ConfirmViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self getSetupValidationInfo];
    self.lbRestaurantsName.text = [Util objectForKey:kPreferenceCardName];
    [self displayDataOnView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)getSetupValidationInfo
{
    BOOL isValidateAddress = [[Util objectForKey:kPreferenceEnableValidateAddress] boolValue];
    BOOL isValidatePhone = [[Util objectForKey:kPreferenceEnableValidatePhone] boolValue];
    BOOL isValidateBirthday = [[Util objectForKey:kPreferenceEnableValidateBirthday] boolValue];
    
    self.imgStarValidateZipCode.hidden = isValidateAddress ? NO : YES;
    self.imgStarValidateAddress.hidden = isValidateAddress ? NO : YES;
    self.imgStarValidatePhone.hidden = isValidatePhone ? NO : YES;
    self.imgStarValidateBirthday.hidden = isValidateBirthday ? NO : YES;
}

#pragma mark ----- Load Data -----
- (void)displayDataOnView
{
    self.lbFirstNameKanji.text = [Util objectForKey:kDataFirstNameKanji];
    self.lbLastNameKanji.text = [Util objectForKey:kDataLastNameKanji];
    self.lbFirstNameHiragana.text = [Util objectForKey:kDataFirstNameHiragana];
    self.lbLastNameHiragana.text = [Util objectForKey:kDataLastNameHiragana];
    self.lbNameYobidashi.text = [Util objectForKey:kDataNameYobidashi];
    self.lbFirstPostNumber.text = [Util objectForKey:kDataFirstPostNumber];
    self.lbLastPostNumber.text = [Util objectForKey:kDataLastPostNumber];
    self.txtViewAddressDetail.text = [NSString stringWithFormat:@"%@\n%@\n%@ %@\n%@",
                                      [Util objectForKey:kDataPrefectureName],
                                      [Util objectForKey:kDataCityName],
                                      [Util objectForKey:kDataTownName],
                                      [Util objectForKey:kDataAreaName],
                                      [Util objectForKey:kDataBuildingName]];
    self.lbFirstPhoneNumber.text = [Util objectForKey:kDataFirstHomePhoneNumber];
    self.lbMidPhoneNumber.text = [Util objectForKey:kDataMidHomePhoneNumber];
    self.lbLastPhoneNumber.text = [Util objectForKey:kDataLastHomePhoneNumber];
    self.lbFirstMobileNumber.text = [Util objectForKey:kDataFirstMobilePhoneNumber];
    self.lbMidMobileNumber.text = [Util objectForKey:kDataMidMobilePhoneNumber];
    self.lbLastMobileNumber.text = [Util objectForKey:kDataLastMobilePhoneNumber];
    self.lbYearBirthday.text = [Util objectForKey:kDataYearBirthday];
    self.lbMonthBirthday.text = [Util objectForKey:kDataMonthBirthday];
    self.lbDayBirthday.text = [Util objectForKey:kDataDayBirthday];
    NSInteger sex = [[Util objectForKey:kDataGender] integerValue];
    if (sex == 1) {
        self.lbGender.text = kStrGenderIsMale;
    }else if (sex == 2)
    {
        self.lbGender.text = kStrGenderIsFemale;
    }else
    {
        self.lbGender.text = @"";
    }
    
    NSString *strFirstEmail = [Util objectForKey:kDataFirstEmail];
    NSString *strLastEmail = [Util objectForKey:kDataLastEmail];
    if ([strFirstEmail isEqualToString:K_STRING_EMPTY] && [strLastEmail isEqualToString:K_STRING_EMPTY]) {
        self.lbCharacterSpecialEmail.hidden = TRUE;
    }else
    {
        self.lbCharacterSpecialEmail.hidden = FALSE;
        self.lbFirstEmail.text = strFirstEmail;
        self.lbLastEmail.text = strLastEmail;
    }
    NSString *strPassword = [Util objectForKey:kDataPassWord];
    if ([strPassword length] > 2) {
        NSString *firstTwoLetter = [strPassword substringToIndex:2];
        NSMutableString *dottedPassword = [NSMutableString new];
        for (int i = 2; i < [strPassword length]; i++)
        {
            [dottedPassword appendString:@"*"];
        }
        self.lbPassword.text = [NSString stringWithFormat:@"%@%@",firstTwoLetter,dottedPassword];
    }
    self.lbMagazineEmailNotifi.text = [[Util objectForKey:kDataAllowSendMagazineEmail] boolValue] ? kStrAllowSendMagazineEmail : kStrNotAllowSendMagazineEmail;
    self.lbDirectEmailNotifi.text = [[Util objectForKey:kDataAllowSendDirectEmail] boolValue] ? kStrAllowSendDirectEmail : kStrNotAllowSendDirectEmail;
}

- (void)presentInfoViewController
{
    InfoViewController *infoVC = [[InfoViewController alloc] initWithNibName:NibInfoVC bundle:nil];
    [Util appDelegate].window.rootViewController = infoVC;
}
#pragma mark ----- UIButton -----
- (IBAction)btnBackRegisterClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    
    int memType = [[Util objectForKey:kDataUserDefaultMemberType] intValue];
    if (memType == 1) {
        RegisterViewController *registerVC = [[RegisterViewController alloc] initWithNibName:NibRegisterVC bundle:nil];
        [Util appDelegate].window.rootViewController = registerVC;
    }else
    {
        RegisterViewController *registerVC = [[RegisterViewController alloc] initWithNibName:NibRegisterQRVC bundle:nil];
        [Util appDelegate].window.rootViewController = registerVC;
    }
    

}
- (IBAction)btnGotoInfoClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    __block id copy_self = self;
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDAnimationFade;
    hud.labelText = LB_MB_SEND_DATA;
    
    NSString *strJsonData = [self generateJsonStringFromDb];
    [[APIClient registerSharedClient] sendData:strJsonData completion:^(ResponseObject *obj) {
        [hud hide:YES];
        if (obj.statusCode == status_api_ok) {
            NSInteger receiptId = [Util validateInteger:obj.data[@"receipt_id"]];
            [Util setObject:@(receiptId) forKey:kDataUserDefaultReceiptId];
            [copy_self presentInfoViewController];
        }else
        {
            [copy_self processErrorCode:obj.statusCode];
        }
    }];
}

#pragma mark ----- Private method -----
- (NSString *)generateJsonStringFromDb
{
    NSString *strBirthday = K_STRING_EMPTY;
    NSString *strYearBirthday = [Util objectForKey:kDataYearBirthday];
    NSString *strMonthBirthday = [NSString stringWithFormat:@"%02d", [[Util objectForKey:kDataMonthBirthday] intValue]];
    NSString *strDayBirthday = [NSString stringWithFormat:@"%02d", [[Util objectForKey:kDataDayBirthday] intValue]];
    if (![strYearBirthday isEqualToString:K_STRING_EMPTY] && ![strMonthBirthday isEqualToString:K_STRING_EMPTY] && ![strDayBirthday isEqualToString:K_STRING_EMPTY]) {
        strBirthday = [NSString stringWithFormat:@"%@-%@-%@", strYearBirthday, strMonthBirthday, strDayBirthday];
    }
    
    NSString *strEmail = K_STRING_EMPTY;
    NSString *strFirstEmail = [Util objectForKey:kDataFirstEmail];
    NSString *strLastEmail = [Util objectForKey:kDataLastEmail];
    if (![strFirstEmail isEqualToString:K_STRING_EMPTY] && ![strLastEmail isEqualToString:K_STRING_EMPTY]) {
        strEmail = [NSString stringWithFormat:@"%@@%@",strFirstEmail,strLastEmail];
    }
    NSInteger mailmaga_disable_flag;
    if ([[Util objectForKey:kDataAllowSendMagazineEmail] boolValue]) {
        mailmaga_disable_flag = 2;
    }else
    {
        mailmaga_disable_flag = 1;
    }
    NSInteger dm_disable_flag;
    if ([[Util objectForKey:kDataAllowSendDirectEmail] boolValue]) {
        dm_disable_flag = 2;
    }else
    {
        dm_disable_flag = 1;
    }
    NSDate *date= [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *receiptDate = [dateFormatter stringFromDate:date];
    
    NSDictionary *dictData = @{kJsonMemberId : [Util objectForKey:kDataMemberId],
                               kJsonFirstNameKanji : [Util objectForKey:kDataFirstNameKanji],
                               kJsonReceiptDate : receiptDate,
                               kJsonLastNameKanji : [Util objectForKey:kDataLastNameKanji],
                               kJsonFirstNameKana : [Util objectForKey:kDataFirstNameHiragana],
                               kJsonLastNameKana : [Util objectForKey:kDataLastNameHiragana],
                               kJsonNameYobidashi : [Util objectForKey:kDataNameYobidashi],
                               kJsonFirstPostNumber : [Util objectForKey:kDataFirstPostNumber],
                               kJsonLastPostNumber : [Util objectForKey:kDataLastPostNumber],
                               kJsonPrefName : [Util objectForKey:kDataPrefectureName],
                               kJsonCityName : [Util objectForKey:kDataCityName],
                               kJsonTownName : [Util objectForKey:kDataTownName],
                               kJsonAreaName : [Util objectForKey:kDataAreaName],
                               kJsonBuildingName : [Util objectForKey:kDataBuildingName],
                               kJsonFirstTelNumber : [Util objectForKey:kDataFirstHomePhoneNumber],
                               kJsonMidTelNumber : [Util objectForKey:kDataMidHomePhoneNumber],
                               kJsonLastTelNumber : [Util objectForKey:kDataLastHomePhoneNumber],
                               kJsonFirstMobileNumber : [Util objectForKey:kDataFirstMobilePhoneNumber],
                               kJsonMidMobileNumber : [Util objectForKey:kDataMidMobilePhoneNumber],
                               kJsonLastMobileNumber : [Util objectForKey:kDataLastMobilePhoneNumber],
                               kJsonFirstOtherTelNumber : [Util objectForKey:kDataFirstOtherTelNumber],
                               kJsonMidOtherTelNumber : [Util objectForKey:kDataMidOtherTelNumber],
                               kJsonLastOtherTelNumber : [Util objectForKey:kDataLastOtherTelNumber],
                               kJsonBirthDay : strBirthday,
                               kJsonGender : [Util objectForKey:kDataGender],
                               kJsonEmailAddress : strEmail,
                               kJsonPassword : [Util objectForKey:kDataPassWord],
                               kJsonSendMaganizeMail : [NSNumber numberWithInteger:mailmaga_disable_flag],
                               kJsonSendDirectMail : [NSNumber numberWithInteger:dm_disable_flag],
                               kJsonMemberType : [NSNumber numberWithInteger:1]}; // set default member type value is 1
    return [self jsonStringPretty:dictData];
}
- (NSString *)jsonStringPretty:(id)data
{
    NSError* error = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:data options:NSJSONWritingPrettyPrinted error:&error];
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return jsonString;
}
#pragma mark ----- Process Error -----
- (void)processErrorCode:(NSInteger)code{
    NSString *msg = [APIClient errorCodeMessageWithCode:code];
    if (msg != nil) {
        [Util showMessage:msg withTitle:LB_ALERT_TITLE_ERR];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
