//
//  LoginViewController.m
//  PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/13.
//  Copyright (c) 2016年 OA-Center Company. All rights reserved.
//

#import "LoginViewController.h"
#import "SetupPrinterViewController.h"
#import "TopViewController.h"
@interface LoginViewController ()
@property (strong, nonatomic) IBOutlet UITextField *txtFieldUserID;
@property (strong, nonatomic) IBOutlet UITextField *txtFieldUserPW;
@property (strong, nonatomic) IBOutlet UILabel *lbNotifiSetupPrinter;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.lbNotifiSetupPrinter.text = LB_NOTIFI_SETUP_PRINTER;
    [Util setObject:@"" forKey:kDataUserDefaultTenantId];
    [Util setObject:@"" forKey:kDataUserDefaultShopId];
    [Util setObject:@"" forKey:kDataUserDefaultShopAuthCode];
    [Util setObject:@"" forKey:kDataUserDefaultShopName];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnSetupPrinterClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    SetupPrinterViewController *setupPrinterVC = [[SetupPrinterViewController alloc] initWithNibName:NibSetupVC bundle:nil];
    [Util appDelegate].window.rootViewController = setupPrinterVC;

}
- (IBAction)btnLoginClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    [self.txtFieldUserID resignFirstResponder];
    [self.txtFieldUserPW resignFirstResponder];
    
    if ([self.txtFieldUserID.text isEqualToString:@""] && [self.txtFieldUserPW.text isEqualToString:@""]) {
        [Util showMessage:ALERT_MSG_ID_PASS_ERR withTitle:LB_ALERT_TITLE_ERR];
    }else
    {
        if ([self.txtFieldUserID.text isEqualToString:@""]) {
            [Util showMessage:ALERT_MSG_ID_ERR withTitle:LB_ALERT_TITLE_ERR];
        }else if ([self.txtFieldUserPW.text isEqualToString:@""]){
            [Util showMessage:ALERT_MSG_PASS_ERR withTitle:LB_ALERT_TITLE_ERR];
        }else
        {
            [self loginWithID:self.txtFieldUserID.text andPassWord:self.txtFieldUserPW.text];
        }
    }
}

- (void)loginWithID:(NSString *)userID andPassWord:(NSString *)userPass;
{
    __block id copy_self = self;  
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDAnimationFade;
    hud.labelText = LB_MB_LOGIN;
    [[APIClient wpSharedClient] login:userID password:userPass completion:^(ResponseObject *obj) {
        [hud hide:YES];
        if (obj.statusCode == status_api_wp_ok) {
            NSString *tenant_id = [Util validateString:obj.data[kJsonTenantId]];
            NSString *shop_id = [Util validateString:obj.data[kJsonShopId]];
            NSString *shop_auth_code = [Util validateString:obj.data[kJsonShopAuthCode]];
            NSString *shop_name = [Util validateString:obj.data[kJsonShopName]];
            [Util setObject:tenant_id forKey:kDataUserDefaultTenantId];
            [Util setObject:shop_id forKey:kDataUserDefaultShopId];
            [Util setObject:shop_auth_code forKey:kDataUserDefaultShopAuthCode];
            [Util setObject:shop_name forKey:kDataUserDefaultShopName];
            [copy_self presentTopViewController];
        }else
        {
            [copy_self processErrorCode:obj.statusCode];
        }
    }];
}
- (void)presentTopViewController
{
    TopViewController *topVC = [[TopViewController alloc] initWithNibName:NibTopVC bundle:nil];
    [Util appDelegate].window.rootViewController = topVC;
}

#pragma mark ----- TextFieldDelegate -----
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender {
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        [[UIMenuController sharedMenuController] setMenuVisible:NO animated:NO];
    }];
    return [super canPerformAction:action withSender:sender];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    return [textField resignFirstResponder];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.txtFieldUserID resignFirstResponder];
    [self.txtFieldUserPW resignFirstResponder];
}

#pragma mark ----- Process Error -----
- (void)processErrorCode:(NSInteger)code{
    NSString *msg = nil;
    if (code == status_api_wp_no_data) {
        msg = ALERT_MSG_API_WP_LOGIN_ERR;
    }else
    {
        msg = [APIClient errorCodeMessageWithCode:code];
    }
    
    if (msg != nil) {
        [Util showMessage:msg withTitle:LB_ALERT_TITLE_ERR];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
