//
//  RegisterViewController.m
//  WP_PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/02.
//  Copyright © 2016年 OA-Center Company. All rights reserved.
//

#import "RegisterViewController.h"
#import "Constants.h"
#import "Validator.h"
#import "TopViewController.h"
#import "ConfirmViewController.h"

@interface RegisterViewController ()
{
    BOOL hasTransView;
    BOOL isAllowSendMagazineEmail;
    BOOL isAllowSendDirectEmail;
    BOOL isValidateAddress;
    BOOL isValidatePhone;
    BOOL isValidateBirthday;
    CGRect vRegisterFrame;
    NSInteger gender;
}
@property (nonatomic, strong) NSXMLParser *xmlParser;
@property (nonatomic, strong) NSMutableArray *arrAddressData;
@property (nonatomic, strong) NSMutableDictionary *dictTempData;

@property (strong, nonatomic) IBOutlet UIImageView *imgStarValidateZipCode;
@property (strong, nonatomic) IBOutlet UIImageView *imgStarValidatePref;
@property (strong, nonatomic) IBOutlet UIImageView *imgStarValidateCity;
@property (strong, nonatomic) IBOutlet UIImageView *imgStarValidateTown;
@property (strong, nonatomic) IBOutlet UIImageView *imgStarValidateArea;
@property (strong, nonatomic) IBOutlet UIImageView *imgStarValidatePhone;
@property (strong, nonatomic) IBOutlet UIImageView *imgStarValidateBirthday;
@property (strong, nonatomic) IBOutlet UIImageView *imgStarValidatePassword;

@property (strong, nonatomic) IBOutlet UILabel *lbTextNameKanji;
@property (strong, nonatomic) IBOutlet UILabel *lbTextNameKana;
@property (strong, nonatomic) IBOutlet UILabel *lbTextNameYobidashi;
@property (strong, nonatomic) IBOutlet UILabel *lbTextZipCode;
@property (strong, nonatomic) IBOutlet UILabel *lbTextPrefName;
@property (strong, nonatomic) IBOutlet UILabel *lbTextCityName;
@property (strong, nonatomic) IBOutlet UILabel *lbTextTownName;
@property (strong, nonatomic) IBOutlet UILabel *lbTextAreaName;
@property (strong, nonatomic) IBOutlet UILabel *lbTextPhone;
@property (strong, nonatomic) IBOutlet UILabel *lbTextBirthday;
@property (strong, nonatomic) IBOutlet UILabel *lbTextGender;
@property (strong, nonatomic) IBOutlet UILabel *lbTextPassword;
@property (strong, nonatomic) IBOutlet UILabel *lbTextEmail;
@property (strong, nonatomic) IBOutlet UILabel *lbTextBuilding;

@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(willHideKeyboard) name:UIKeyboardWillHideNotification object:nil];
    [self refreshTextColor];
    [self getSetupValidationInfo];
    vRegisterFrame = self.vRegister.frame;
    self.lbRestaurantName.text = [Util objectForKey:kPreferenceCardName];
    [self displayUserInformation];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)refreshTextColor
{
    self.lbTextNameKanji.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
    self.lbTextNameKana.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
    self.lbTextNameYobidashi.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
    self.lbTextZipCode.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
    self.lbTextPrefName.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
    self.lbTextCityName.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
    self.lbTextTownName.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
    self.lbTextAreaName.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
    self.lbTextBuilding.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
    self.lbTextPhone.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
    self.lbTextBirthday.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
    self.lbTextGender.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
    self.lbTextPassword.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
    self.lbTextEmail.textColor = RGB(LB_STANDARD_COLOR, LB_STANDARD_COLOR, LB_STANDARD_COLOR);
}
#pragma mark ----- UIView animation -----
- (void)willHideKeyboard
{
    if (hasTransView) {
        [self transitionDownView];
    }
}
- (void)transitionUpView:(id)sender withTag:(NSInteger)txtFieldTag
{
    hasTransView = TRUE;
    [UIView animateWithDuration:0.3 animations:^{
        [self.vRegister setFrame:CGRectMake(vRegisterFrame.origin.x, vRegisterFrame.origin.y - ANIMATION_HEIGHT, vRegisterFrame.size.width, vRegisterFrame.size.height)];
    } completion:^(BOOL finished) {
        [self showPopoverAtPosition:sender withMode:SELECT_NOTIFI txtTag:txtFieldTag];
    }];
}
- (void)transitionDownView
{
     hasTransView = FALSE;
    [UIView animateWithDuration:0.3 animations:^{
        [self.vRegister setFrame:CGRectMake(vRegisterFrame.origin.x, vRegisterFrame.origin.y, vRegisterFrame.size.width, vRegisterFrame.size.height)];
    }];
    
}
- (void)transitionDownView:(id)sender withTag:(NSInteger)txtFieldTag
{
    hasTransView = FALSE;
    [UIView animateWithDuration:0.3 animations:^{
        [self.vRegister setFrame:CGRectMake(vRegisterFrame.origin.x, vRegisterFrame.origin.y, vRegisterFrame.size.width, vRegisterFrame.size.height)];
    } completion:^(BOOL finished) {
        [self showPopoverAtPosition:sender withMode:SELECT_NOTIFI txtTag:txtFieldTag];
    }];
}
#pragma mark ----- Private method implementation -----
- (void)getSetupValidationInfo
{
    isValidateAddress = [[Util objectForKey:kPreferenceEnableValidateAddress] boolValue];
    isValidatePhone = [[Util objectForKey:kPreferenceEnableValidatePhone] boolValue];
    isValidateBirthday = [[Util objectForKey:kPreferenceEnableValidateBirthday] boolValue];
    
    self.imgStarValidateZipCode.hidden = isValidateAddress ? NO : YES;
    self.imgStarValidatePref.hidden = isValidateAddress ? NO : YES;
    self.imgStarValidateCity.hidden = isValidateAddress ? NO : YES;
    self.imgStarValidateTown.hidden = isValidateAddress ? NO : YES;
    self.imgStarValidateArea.hidden = isValidateAddress ? NO : YES;
    self.imgStarValidatePhone.hidden = isValidatePhone ? NO : YES;
    self.imgStarValidateBirthday.hidden = isValidateBirthday ? NO : YES;
}
-(void)downloadAddressInfo{
    NSString *strPostCode = [NSString stringWithFormat:@"%@%@",self.txtFieldFirstPostNumber.text,self.txtFieldLastPostNumber.text];
    NSString *URLString = [NSString stringWithFormat:@"%@%@",kApiUrlGetAddress,strPostCode];
    NSURL *url = [NSURL URLWithString:URLString];
    [AppDelegate downloadAddressFromURL:url withCompletionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error != nil) {
            [Util showMessage:[error localizedDescription] withTitle:LB_ALERT_TITLE_ERR];
        }else{
            NSInteger HTTPStatusCode = [(NSHTTPURLResponse *)response statusCode];
            if (HTTPStatusCode != 200) {
                NSInteger HTTPStatusCode = [(NSHTTPURLResponse *)response statusCode];
                [self processErrorCode:HTTPStatusCode];
            }
            if (data != nil) {
                self.xmlParser = [[NSXMLParser alloc] initWithData:data];
                self.xmlParser.delegate = self;
                [self.xmlParser parse];
            }else
            {
                [Util showMessage:ALERT_MSG_NO_RESULT_WITH_ZIPCODE withTitle:LB_ALERT_TITLE_ERR];
            }
        }
    }];
}

- (void)displayUserInformation
{
    self.txtFieldFirstNameKanji.text = [Util objectForKey:kDataFirstNameKanji];
    self.txtFieldLastNameKanji.text = [Util objectForKey:kDataLastNameKanji];
    self.txtFieldFirstNameHiragana.text = [Util objectForKey:kDataFirstNameHiragana];
    self.txtFieldLastNameHiragana.text = [Util objectForKey:kDataLastNameHiragana];
    self.txtFieldNameYobidashi.text = [Util objectForKey:kDataNameYobidashi];
    self.txtFieldFirstPostNumber.text = [Util objectForKey:kDataFirstPostNumber];
    self.txtFieldLastPostNumber.text = [Util objectForKey:kDataLastPostNumber];
    self.lbPrefecturesName.text = [Util objectForKey:kDataPrefectureName];
    self.txtFieldCityName.text = [Util objectForKey:kDataCityName];
    self.txtFieldTownName.text = [Util objectForKey:kDataTownName];
    self.txtFieldAreaName.text = [Util objectForKey:kDataAreaName];
    self.txtFieldBuildingName.text = [Util objectForKey:kDataBuildingName];
    self.txtFieldFirstPhoneNumber.text = [Util objectForKey:kDataFirstHomePhoneNumber];
    self.txtFieldMidPhoneNumber.text = [Util objectForKey:kDataMidHomePhoneNumber];
    self.txtFieldLastPhoneNumber.text = [Util objectForKey:kDataLastHomePhoneNumber];
    self.txtFieldFirstMobileNumber.text = [Util objectForKey:kDataFirstMobilePhoneNumber];
    self.txtFieldMidMobileNumber.text = [Util objectForKey:kDataMidMobilePhoneNumber];
    self.txtFieldLastMobileNumber.text = [Util objectForKey:kDataLastMobilePhoneNumber];
    self.lbSelectYearBirthday.text = [Util objectForKey:kDataYearBirthday];
    self.lbSelectMonthBirthday.text = [Util objectForKey:kDataMonthBirthday];
    self.lbSelectDayBirthday.text = [Util objectForKey:kDataDayBirthday];
    
    NSInteger sex = [[Util objectForKey:kDataGender] integerValue];
    if(sex == 2) {
        gender = 2;
        [self.btnMale setBackgroundImage:[UIImage imageNamed:kIMG_RADIO_GRAY] forState:UIControlStateNormal];
        [self.btnFemale setBackgroundImage:[UIImage imageNamed:kIMG_RADIO_GREEN] forState:UIControlStateNormal];
    }else
    {
        gender = 1;
        [self.btnMale setBackgroundImage:[UIImage imageNamed:kIMG_RADIO_GREEN] forState:UIControlStateNormal];
        [self.btnFemale setBackgroundImage:[UIImage imageNamed:kIMG_RADIO_GRAY] forState:UIControlStateNormal];
    }
    self.txtFieldFirstMail.text = [Util objectForKey:kDataFirstEmail];
    self.txtFieldLastMail.text = [Util objectForKey:kDataLastEmail];
    self.txtFieldPassword.text = [Util objectForKey:kDataPassWord];
    
    if ([[Util objectForKey:kDataAllowSendMagazineEmail] boolValue]) {
        isAllowSendMagazineEmail = TRUE;
        [self.btnMagazineEmail setBackgroundImage:[UIImage imageNamed:kIMG_CHECKED_GREEN] forState:UIControlStateNormal];
    }else
    {
        isAllowSendMagazineEmail = FALSE;
        [self.btnMagazineEmail setBackgroundImage:[UIImage imageNamed:kIMG_CHECKED_GRAY] forState:UIControlStateNormal];
    }
    if ([[Util objectForKey:kDataAllowSendDirectEmail] boolValue]) {
        isAllowSendDirectEmail = TRUE;
        [self.btnDirectEmail setBackgroundImage:[UIImage imageNamed:kIMG_CHECKED_GREEN] forState:UIControlStateNormal];
        
    }else
    {
        isAllowSendDirectEmail = FALSE;
        [self.btnDirectEmail setBackgroundImage:[UIImage imageNamed:kIMG_CHECKED_GRAY] forState:UIControlStateNormal];
    }
}
- (void)saveDataToUserDefault
{
    [Util setObject:self.txtFieldFirstNameKanji.text forKey:kDataFirstNameKanji];
    [Util setObject:self.txtFieldLastNameKanji.text forKey:kDataLastNameKanji];
    [Util setObject:self.txtFieldFirstNameHiragana.text forKey:kDataFirstNameHiragana];
    [Util setObject:self.txtFieldLastNameHiragana.text forKey:kDataLastNameHiragana];
    [Util setObject:self.txtFieldNameYobidashi.text forKey:kDataNameYobidashi];
    [Util setObject:self.txtFieldFirstPostNumber.text forKey:kDataFirstPostNumber];
    [Util setObject:self.txtFieldLastPostNumber.text forKey:kDataLastPostNumber];
    [Util setObject:self.lbPrefecturesName.text forKey:kDataPrefectureName];
    [Util setObject:self.txtFieldCityName.text forKey:kDataCityName];
    [Util setObject:self.txtFieldTownName.text forKey:kDataTownName];
    [Util setObject:self.txtFieldAreaName.text forKey:kDataAreaName];
    [Util setObject:self.txtFieldBuildingName.text forKey:kDataBuildingName];
    [Util setObject:self.txtFieldFirstPhoneNumber.text forKey:kDataFirstHomePhoneNumber];
    [Util setObject:self.txtFieldMidPhoneNumber.text forKey:kDataMidHomePhoneNumber];
    [Util setObject:self.txtFieldLastPhoneNumber.text forKey:kDataLastHomePhoneNumber];
    [Util setObject:self.txtFieldFirstMobileNumber.text forKey:kDataFirstMobilePhoneNumber];
    [Util setObject:self.txtFieldMidMobileNumber.text forKey:kDataMidMobilePhoneNumber];
    [Util setObject:self.txtFieldLastMobileNumber.text forKey:kDataLastMobilePhoneNumber];
    [Util setObject:self.lbSelectYearBirthday.text forKey:kDataYearBirthday];
    [Util setObject:self.lbSelectMonthBirthday.text forKey:kDataMonthBirthday];
    [Util setObject:self.lbSelectDayBirthday.text forKey:kDataDayBirthday];
    [Util setObject:[NSNumber numberWithInteger:gender] forKey:kDataGender];
    [Util setObject:self.txtFieldFirstMail.text forKey:kDataFirstEmail];
    [Util setObject:self.txtFieldLastMail.text forKey:kDataLastEmail];

    int memType = [[Util objectForKey:kDataUserDefaultMemberType] intValue];
    if (memType == 1) {
        [Util setObject:self.txtFieldPassword.text forKey:kDataPassWord];
    }else
    {
        [Util setObject:@"" forKey:kDataPassWord];
    }
    
    [Util setObject:[NSNumber numberWithBool:isAllowSendMagazineEmail] forKey:kDataAllowSendMagazineEmail];
    [Util setObject:[NSNumber numberWithBool:isAllowSendDirectEmail] forKey:kDataAllowSendDirectEmail];
}

- (void)presentTopViewController
{
    TopViewController *topVC = [[TopViewController alloc] initWithNibName:NibTopVC bundle:nil];
    [Util appDelegate].window.rootViewController = topVC;
}
- (void)saveDataAndPresentConfirmViewController
{
    [self saveDataToUserDefault];
    int memType = [[Util objectForKey:kDataUserDefaultMemberType] intValue];
    if (memType == 1) {
        ConfirmViewController *confirmVC = [[ConfirmViewController alloc] initWithNibName:NibConfirmVC bundle:nil];
        [Util appDelegate].window.rootViewController = confirmVC;
    }else
    {
        ConfirmViewController *confirmVC = [[ConfirmViewController alloc] initWithNibName:NibConfirmQRVC bundle:nil];
        [Util appDelegate].window.rootViewController = confirmVC;
    }
}
- (void)showMsgEmailExist
{
    self.lbTextEmail.textColor = [UIColor redColor];
    [Util showMessage:ALERT_MSG_EMAIL_EXIST withTitle:LB_ALERT_TITLE_ERR];
}
#pragma mark ----- UIButton -----
- (IBAction)btnBackTopClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    if ([self isExistData]) {
        [Util showMessage:LB_ALERT_MSG_BACK_TOP
                withTitle:LB_ALERT_TITLE_CONFIRM
        cancelButtonTitle:LB_ALERT_BTN_CANCEL
        otherButtonTitles:LB_ALERT_BTN_OK
                 delegate:self andTag:1];
    }else
    {
        [self presentTopViewController];
    }

}
- (IBAction)btnConfirmClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    [self refreshTextColor];
    if (![self isEnoughData]) {
        [Util showMessage:ALERT_MSG_VALIDATE_ERR withTitle:LB_ALERT_TITLE_ERR];
        return;
    }
    
    int memType = [[Util objectForKey:kDataUserDefaultMemberType] intValue];
    if (memType == 1) {
        NSString *shopAuthCode = [Util objectForKey:kDataUserDefaultShopAuthCode];
        __block id copy_self = self;
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.mode = MBProgressHUDAnimationFade;
        hud.labelText = LB_MB_VERIFY_USER_DATA;
        
        NSString *strEmail = [NSString stringWithFormat:@"%@@%@",self.txtFieldFirstMail.text, self.txtFieldLastMail.text];
        
        [[APIClient wpSharedClient] checkExistEmailWithShopAuthCode:shopAuthCode email:strEmail completion:^(ResponseObject *obj) {
            [hud hide:YES];
            if (obj.statusCode == status_api_wp_ok) {
                // This email had registered
                [copy_self showMsgEmailExist];
            }else if (obj.statusCode == status_api_wp_no_data)
            {
                // This email doesn't registration
                [copy_self saveDataAndPresentConfirmViewController];
            }else
            {
                [copy_self processErrorCode:obj.statusCode];
            }
        }];

    }else
    {
        [self saveDataAndPresentConfirmViewController];
    }

}
- (IBAction)btnFindAddressClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    
    if ([self.txtFieldFirstPostNumber.text isEqualToString:K_STRING_EMPTY] || [self.txtFieldLastPostNumber.text isEqualToString:K_STRING_EMPTY] ||
        (![self.txtFieldFirstPostNumber.text isEqualToString:K_STRING_EMPTY] && [self.txtFieldFirstPostNumber.text length] < AMOUNT_NUMBER_THREE) ||
        (![self.txtFieldLastPostNumber.text isEqualToString:K_STRING_EMPTY] && [self.txtFieldLastPostNumber.text length] < AMOUNT_NUMBER_FOUR)) {
        [Util showMessage:ALERT_MSG_ZIPCODE_EMPTY_ERR withTitle:LB_ALERT_TITLE_ERR];
    }else
    {
        [self downloadAddressInfo];
    }
}
- (IBAction)btnFindProvinceClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    [self showPopoverAtPosition:sender withMode:SELECT_PROVINCE txtTag:0];
}
- (IBAction)btnSelectYearClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    [self showPopoverAtPosition:sender withMode:SELECT_YEAR txtTag:0];
}
- (IBAction)btnSelectMonthClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    [self showPopoverAtPosition:sender withMode:SELECT_MONTH txtTag:0];
}
- (IBAction)btnSelectDayClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    [self showPopoverAtPosition:sender withMode:SELECT_DAY txtTag:0];
}
- (IBAction)btnMaleClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    gender = 1;
    [self.btnMale setBackgroundImage:[UIImage imageNamed:kIMG_RADIO_GREEN] forState:UIControlStateNormal];
    [self.btnFemale setBackgroundImage:[UIImage imageNamed:kIMG_RADIO_GRAY] forState:UIControlStateNormal];
}
- (IBAction)btnFemaleClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    gender = 2;
    [self.btnMale setBackgroundImage:[UIImage imageNamed:kIMG_RADIO_GRAY] forState:UIControlStateNormal];
    [self.btnFemale setBackgroundImage:[UIImage imageNamed:kIMG_RADIO_GREEN] forState:UIControlStateNormal];
}
- (IBAction)btnCheckMagazineMailClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    if (isAllowSendMagazineEmail) {
        [self.btnMagazineEmail setBackgroundImage:[UIImage imageNamed:kIMG_CHECKED_GRAY] forState:UIControlStateNormal];
    }else
    {
        [self.btnMagazineEmail setBackgroundImage:[UIImage imageNamed:kIMG_CHECKED_GREEN] forState:UIControlStateNormal];
    }
    isAllowSendMagazineEmail = !isAllowSendMagazineEmail;
}
- (IBAction)btnCheckDirectMailClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    if (isAllowSendDirectEmail) {
        [self.btnDirectEmail setBackgroundImage:[UIImage imageNamed:kIMG_CHECKED_GRAY] forState:UIControlStateNormal];
    }else
    {
        [self.btnDirectEmail setBackgroundImage:[UIImage imageNamed:kIMG_CHECKED_GREEN] forState:UIControlStateNormal];
    }
    isAllowSendDirectEmail = !isAllowSendDirectEmail;
}

#pragma mark ----- Show Popover -----
- (void)showPopoverAtPosition:(id)sender withMode:(SELECT_POPOVER)selectMode txtTag:(NSInteger)txtTag
{
    if (_popoverDate != nil) {
        _popoverDate = nil;
    }
    
    _popoverDate = [[PopoverDate alloc] initWithStyle:UITableViewStylePlain];
    _popoverDate.selectMode = selectMode;
    _popoverDate.txtFieldTag = txtTag;
    _popoverDate.delegate = self;
    
    if (_popoverDateController != nil) {
        [_popoverDateController dismissPopoverAnimated:YES];
        _popoverDateController = nil;
    }
    
    if (selectMode == SELECT_NOTIFI) {
        UITextField *txtField = (UITextField *)sender;
        _popoverDateController = [[UIPopoverController alloc] initWithContentViewController:_popoverDate];
        _popoverDateController.backgroundColor = [UIColor colorWithRed:(210.0f/255.0f) green:(255.0f/255.0f) blue:(255.0f/255.0f) alpha:1.0f];
        [_popoverDateController presentPopoverFromRect:txtField.bounds inView:txtField permittedArrowDirections:(UIPopoverArrowDirectionDown) animated:YES];
    }else
    {
        UIButton *button = (UIButton *)sender;
        _popoverDateController = [[UIPopoverController alloc] initWithContentViewController:_popoverDate];
        [_popoverDateController presentPopoverFromRect:button.bounds inView:button permittedArrowDirections:(UIPopoverArrowDirectionRight) animated:YES];
    }
}
- (void)hidePopover
{
    if (_popoverDateController) {
        [_popoverDateController dismissPopoverAnimated:YES];
        _popoverDateController = nil;
    }
}

#pragma mark ----- UIAlertViewDelegate -----
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    if (buttonIndex == 1) {
        if (alertView.tag == 1) {
            [self presentTopViewController];
        }
    }
}
#pragma mark ----- UITextFieldDelegate -----
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self hidePopover];
    [self.txtFieldFirstNameKanji resignFirstResponder];
    [self.txtFieldLastNameKanji resignFirstResponder];
    [self.txtFieldFirstNameHiragana resignFirstResponder];
    [self.txtFieldLastNameHiragana resignFirstResponder];
    [self.txtFieldNameYobidashi resignFirstResponder];
    [self.txtFieldFirstPostNumber resignFirstResponder];
    [self.txtFieldLastPostNumber resignFirstResponder];
    [self.txtFieldCityName resignFirstResponder];
    [self.txtFieldTownName resignFirstResponder];
    [self.txtFieldAreaName resignFirstResponder];
    [self.txtFieldBuildingName resignFirstResponder];
    [self.txtFieldFirstPhoneNumber resignFirstResponder];
    [self.txtFieldMidPhoneNumber resignFirstResponder];
    [self.txtFieldLastPhoneNumber resignFirstResponder];
    [self.txtFieldFirstMobileNumber resignFirstResponder];
    [self.txtFieldMidMobileNumber resignFirstResponder];
    [self.txtFieldLastMobileNumber resignFirstResponder];
    [self.txtFieldFirstMail resignFirstResponder];
    [self.txtFieldLastMail resignFirstResponder];
    [self.txtFieldPassword resignFirstResponder];
    if (hasTransView ) {
        [self transitionDownView];
    }
}
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender {
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        [[UIMenuController sharedMenuController] setMenuVisible:NO animated:NO];
    }];
    return [super canPerformAction:action withSender:sender];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    id sender = textField;
    
    
    if (textField == self.txtFieldFirstNameKanji || textField == self.txtFieldLastNameKanji ||
        textField == self.txtFieldFirstNameHiragana || textField == self.txtFieldLastNameHiragana ||
        textField == self.txtFieldNameYobidashi || textField == self.txtFieldCityName||
        textField == self.txtFieldTownName || textField == self.txtFieldBuildingName) {
        if (hasTransView) {
            [self transitionDownView:sender withTag:textField.tag];
        }else
        {
            [self showPopoverAtPosition:sender withMode:SELECT_NOTIFI txtTag:textField.tag];
        }
        // Keyboard show with kana type
        [textField setKeyboardType:UIKeyboardTypeDefault];
        
    }else if (textField == self.txtFieldFirstPostNumber || textField == self.txtFieldLastPostNumber ||
              textField == self.txtFieldAreaName || textField == self.txtFieldFirstPhoneNumber ||
              textField == self.txtFieldMidPhoneNumber || textField == self.txtFieldLastPhoneNumber ||
              textField == self.txtFieldFirstMobileNumber || textField == self.txtFieldMidMobileNumber ||
              textField == self.txtFieldLastMobileNumber)
    {
        if (hasTransView) {
            [self transitionDownView:sender withTag:textField.tag];
        }else
        {
            [self showPopoverAtPosition:sender withMode:SELECT_NOTIFI txtTag:textField.tag];
        }
        // Keyboard show with number type
        [textField setKeyboardType:UIKeyboardTypeNumberPad];
    
    }else if (textField == self.txtFieldFirstMail || textField == self.txtFieldLastMail ||
              textField == self.txtFieldPassword)
    {
        if (!hasTransView) {
            [self transitionUpView:sender withTag:textField.tag];
        }else
        {
            [self showPopoverAtPosition:sender withMode:SELECT_NOTIFI txtTag:textField.tag];
        }
        // Keyboard show with US type
        [textField setKeyboardType:UIKeyboardTypeASCIICapable];
    }else
    {
        if (hasTransView) {
            [self transitionDownView:sender withTag:textField.tag];
        }else
        {
            [self showPopoverAtPosition:sender withMode:SELECT_NOTIFI txtTag:textField.tag];
        }
    }

}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self hidePopover];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self hidePopover];
    return [textField resignFirstResponder];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField == self.txtFieldFirstNameKanji || textField == self.txtFieldLastNameKanji ||
        textField == self.txtFieldFirstNameHiragana || textField == self.txtFieldLastNameHiragana ||
        textField == self.txtFieldNameYobidashi || textField == self.txtFieldCityName||
        textField == self.txtFieldTownName || textField == self.txtFieldBuildingName ||
        textField == self.txtFieldAreaName) {
        // Keyboard show with kana type
        if (textField == self.txtFieldFirstNameKanji || textField == self.txtFieldLastNameKanji ||
            textField == self.txtFieldFirstNameHiragana || textField == self.txtFieldLastNameHiragana) {
            if ([textField.text length] >= AMOUNT_FIFTY_CHARACTER) {
                return NO;
            }
        }else if (textField == self.txtFieldAreaName || textField == self.txtFieldCityName ||
                  textField == self.txtFieldTownName || textField == self.txtFieldBuildingName)
        {
            if ([textField.text length] >= AMOUNT_ONE_HUNDER_CHARACTER)
            {
                return NO;
            }
        }else if (textField == self.txtFieldNameYobidashi)
        {
            if ([textField.text length] >= AMOUNT_TWENTY_CHARACTER) {
                return NO;
            }
        }
        return YES;
        
    }else if (textField == self.txtFieldFirstPostNumber || textField == self.txtFieldLastPostNumber ||
              textField == self.txtFieldFirstPhoneNumber || textField == self.txtFieldMidPhoneNumber ||
              textField == self.txtFieldLastPhoneNumber || textField == self.txtFieldFirstMobileNumber ||
              textField == self.txtFieldMidMobileNumber || textField == self.txtFieldLastMobileNumber)
    {
        // Keyboard show with number type
        if([string length] == 0)
        {
            return YES;
        }
        
        if (textField == self.txtFieldFirstPostNumber) {
            if ([textField.text length] >= AMOUNT_NUMBER_THREE)
            {
                return NO;
            }
        }else if (textField == self.txtFieldLastPhoneNumber || textField == self.txtFieldLastMobileNumber){
            if ([textField.text length] >= AMOUNT_NUMBER_FIVE) {
                return NO;
            }
        }
        else
        {
            if ([textField.text length] >= AMOUNT_NUMBER_FOUR)
            {
                return NO;
            }
        }
        
        /*  limit to only numeric characters  */
        NSCharacterSet *myCharSet = [NSCharacterSet characterSetWithCharactersInString:K_STRING_NUMBER_IPAD];
        for (int i = 0; i < [string length]; i++) {
            unichar c = [string characterAtIndex:i];
            if ([myCharSet characterIsMember:c]) {
                return YES;
            }
        }
        
    }else if (textField == self.txtFieldFirstMail || textField == self.txtFieldLastMail ||
              textField == self.txtFieldPassword)
    {
        // Keyboard show with US type
        if (textField == self.txtFieldFirstMail || textField == self.txtFieldLastMail) {
            NSString *strEmail = [NSString stringWithFormat:@"%@@%@",self.txtFieldFirstMail.text,self.txtFieldLastMail.text];
            if ([strEmail length] >= AMOUNT_TWO_HUNDER_FIFTY_SIX_CHAR) {
                return NO;
            }
        }
        if (textField == self.txtFieldPassword) {
            if ([self.txtFieldPassword.text length] >= AMOUNT_TWENTY_CHARACTER) {
                return NO;
            }
        }
        
        return YES;
        
    }
    return NO;
}

#pragma mark ----- ValuePickerDelegate method -----
- (void)selectedValue:(int)newValue withMode:(SELECT_POPOVER)mode
{
    [self hidePopover];
    
    switch (mode) {
        case SELECT_PROVINCE:
        {
            [Util setObject:self.lbPrefecturesName.text forKey:kDataPrefectureName];
        }
            break;
        case SELECT_YEAR:
        {
            self.lbSelectYearBirthday.text = [NSString stringWithFormat:@"%d",newValue];
            [Util setObject:self.lbSelectYearBirthday.text forKey:kDataYearBirthday];
        }
            break;
        case SELECT_MONTH:
        {
            self.lbSelectMonthBirthday.text = [NSString stringWithFormat:@"%d",newValue];
            [Util setObject:self.lbSelectMonthBirthday.text forKey:kDataMonthBirthday];
        }
            break;
        case SELECT_DAY:
        {
            self.lbSelectDayBirthday.text = [NSString stringWithFormat:@"%d",newValue];
            [Util setObject:self.lbSelectDayBirthday.text forKey:kDataDayBirthday];
        }
            break;
        default:
            break;
    }
}
- (void)selectedProvince:(NSString *)newValue
{
    [self hidePopover];
    self.lbPrefecturesName.text = newValue;
}
#pragma mark ----- Validate form -----
- (BOOL)isEnoughData
{
    BOOL isValidationPass = TRUE;
    // Everytime validation
    if ([self.txtFieldFirstNameKanji.text isEqualToString:K_STRING_EMPTY] ||
        [self.txtFieldLastNameKanji.text isEqualToString:K_STRING_EMPTY]) {
        
        isValidationPass = FALSE;
        self.lbTextNameKanji.textColor = [UIColor redColor];
    }
    
    if ([self.txtFieldFirstNameHiragana.text isEqualToString:K_STRING_EMPTY] ||
        [self.txtFieldLastNameHiragana.text isEqualToString:K_STRING_EMPTY] ||
        ![Validator isHiraganaString:self.txtFieldFirstNameHiragana.text] ||
        ![Validator isHiraganaString:self.txtFieldLastNameHiragana.text]) {
        
        isValidationPass = FALSE;
        self.lbTextNameKana.textColor = [UIColor redColor];
    }
    
    if ([self.txtFieldNameYobidashi.text isEqualToString:K_STRING_EMPTY] ||
        ![Validator isHiraganaString:self.txtFieldNameYobidashi.text]) {
        
        isValidationPass = FALSE;
        self.lbTextNameYobidashi.textColor = [UIColor redColor];
    }
    int memType = [[Util objectForKey:kDataUserDefaultMemberType] intValue];
    if (memType == 1) { // New user
        NSString *strPassword = self.txtFieldPassword.text;
        if ([strPassword isEqualToString:K_STRING_EMPTY] || ![Validator isCorrectPass:strPassword]) {
            isValidationPass = FALSE;
            self.lbTextPassword.textColor = [UIColor redColor];
        }
    }
    if (gender != 1 && gender != 2) {
        isValidationPass = FALSE;
        self.lbTextGender.textColor = [UIColor redColor];
    }
    
    // Relationship .plist file
    if (isValidateAddress) {
        if ([self.txtFieldFirstPostNumber.text isEqualToString:K_STRING_EMPTY] ||
            [self.txtFieldLastPostNumber.text isEqualToString:K_STRING_EMPTY]) {
            isValidationPass = FALSE;
            self.lbTextZipCode.textColor = [UIColor redColor];
        }
        if ([self.lbPrefecturesName.text isEqualToString:K_STRING_EMPTY]) {
            isValidationPass = FALSE;
            self.lbTextPrefName.textColor = [UIColor redColor];
        }
        if ([self.txtFieldCityName.text isEqualToString:K_STRING_EMPTY]) {
            isValidationPass = FALSE;
            self.lbTextCityName.textColor = [UIColor redColor];
        }
        if ([self.txtFieldTownName.text isEqualToString:K_STRING_EMPTY]) {
            isValidationPass = FALSE;
            self.lbTextTownName.textColor = [UIColor redColor];
        }
        if ([self.txtFieldAreaName.text isEqualToString:K_STRING_EMPTY]) {
            isValidationPass = FALSE;
            self.lbTextAreaName.textColor = [UIColor redColor];
        }
    }
    
    if (isValidatePhone) {
        
        BOOL phoneNumberCorrect = TRUE;
        if ([self.txtFieldFirstPhoneNumber.text isEqualToString:K_STRING_EMPTY] ||
            [self.txtFieldMidPhoneNumber.text isEqualToString:K_STRING_EMPTY] ||
            [self.txtFieldLastPhoneNumber.text isEqualToString:K_STRING_EMPTY]) {
            phoneNumberCorrect = FALSE;
        }
        
        BOOL phoneNumberZero = FALSE;
        if ([self.txtFieldFirstPhoneNumber.text isEqualToString:K_STRING_EMPTY] &&
            [self.txtFieldMidPhoneNumber.text isEqualToString:K_STRING_EMPTY] &&
            [self.txtFieldLastPhoneNumber.text isEqualToString:K_STRING_EMPTY]) {
            phoneNumberZero = TRUE;
        }
        
        BOOL mobileNumberCorrect = TRUE;
        if ([self.txtFieldFirstMobileNumber.text isEqualToString:K_STRING_EMPTY] ||
            [self.txtFieldMidMobileNumber.text isEqualToString:K_STRING_EMPTY] ||
            [self.txtFieldLastMobileNumber.text isEqualToString:K_STRING_EMPTY]) {
            mobileNumberCorrect = FALSE;
        }
        
        BOOL mobileNumberZero = FALSE;
        if ([self.txtFieldFirstMobileNumber.text isEqualToString:K_STRING_EMPTY] &&
            [self.txtFieldMidMobileNumber.text isEqualToString:K_STRING_EMPTY] &&
            [self.txtFieldLastMobileNumber.text isEqualToString:K_STRING_EMPTY]) {
            mobileNumberZero = TRUE;
        }
        
        if ((!phoneNumberCorrect && !mobileNumberCorrect) || (!phoneNumberCorrect && !phoneNumberZero) || (!mobileNumberCorrect && !mobileNumberZero)) {
            isValidationPass = FALSE;
            self.lbTextPhone.textColor = [UIColor redColor];
        }
        
    }
    
    if (isValidateBirthday) {
        if ([self.lbSelectYearBirthday.text isEqualToString:K_STRING_EMPTY] ||
            [self.lbSelectMonthBirthday.text isEqualToString:K_STRING_EMPTY] ||
            [self.lbSelectDayBirthday.text isEqualToString:K_STRING_EMPTY]) {
            isValidationPass = FALSE;
            self.lbTextBirthday.textColor = [UIColor redColor];
        }
    }
    
    // Validate correct format
    if ((![self.txtFieldFirstNameKanji.text isEqualToString:K_STRING_EMPTY] && ([Validator isContainsEmoji:self.txtFieldFirstNameKanji.text] || [Validator isContainsSpecialChar:self.txtFieldFirstNameKanji.text])) ||
        (![self.txtFieldLastNameKanji.text isEqualToString:K_STRING_EMPTY] && ([Validator isContainsEmoji:self.txtFieldLastNameKanji.text] || [Validator isContainsSpecialChar:self.txtFieldLastNameKanji.text]))) {
        isValidationPass = FALSE;
        self.lbTextNameKanji.textColor = [UIColor redColor];
    }
    
    if (![self.txtFieldFirstPostNumber.text isEqualToString:K_STRING_EMPTY] && [self.txtFieldFirstPostNumber.text length] < AMOUNT_NUMBER_THREE) {
        isValidationPass = FALSE;
        self.lbTextZipCode.textColor = [UIColor redColor];
    }
    if (![self.txtFieldLastPostNumber.text isEqualToString:K_STRING_EMPTY] && [self.txtFieldLastPostNumber.text length] < AMOUNT_NUMBER_FOUR) {
        isValidationPass = FALSE;
        self.lbTextZipCode.textColor = [UIColor redColor];
    }
    
    if (![self.txtFieldCityName.text isEqualToString:K_STRING_EMPTY] && ([Validator isContainsEmoji:self.txtFieldCityName.text] || [Validator isContainsSpecialChar:self.txtFieldCityName.text])) {
        isValidationPass = FALSE;
        self.lbTextCityName.textColor = [UIColor redColor];
    }
    
    if (![self.txtFieldTownName.text isEqualToString:K_STRING_EMPTY] && ([Validator isContainsEmoji:self.txtFieldTownName.text] || [Validator isContainsSpecialChar:self.txtFieldTownName.text])) {
        isValidationPass = FALSE;
        self.lbTextTownName.textColor = [UIColor redColor];
    }
    if (![self.txtFieldBuildingName.text isEqualToString:K_STRING_EMPTY] && ([Validator isContainsEmoji:self.txtFieldBuildingName.text] || [Validator isContainsSpecialChar:self.txtFieldBuildingName.text])) {
        isValidationPass = FALSE;
        self.lbTextBuilding.textColor = [UIColor redColor];
    }
    
    if (![self.txtFieldAreaName.text isEqualToString:K_STRING_EMPTY] && ([Validator isContainsEmoji:self.txtFieldAreaName.text] || [Validator isContainsSpecialChar:self.txtFieldAreaName.text])) {
        isValidationPass = FALSE;
        self.lbTextAreaName.textColor = [UIColor redColor];
    }
    
    if (![self.txtFieldFirstPhoneNumber.text isEqualToString:K_STRING_EMPTY] && ![Validator isZeroAtFirstCharacter:self.txtFieldFirstPhoneNumber.text]) {
        isValidationPass = FALSE;
        self.lbTextPhone.textColor = [UIColor redColor];
    }
    if (![self.txtFieldFirstMobileNumber.text isEqualToString:K_STRING_EMPTY] && ![Validator isZeroAtFirstCharacter:self.txtFieldFirstMobileNumber.text]) {
        isValidationPass = FALSE;
        self.lbTextPhone.textColor = [UIColor redColor];
    }
    
    if (![self.lbSelectYearBirthday.text isEqualToString:K_STRING_EMPTY] || ![self.lbSelectMonthBirthday.text isEqualToString:K_STRING_EMPTY] ||
        ![self.lbSelectDayBirthday.text isEqualToString:K_STRING_EMPTY]) {
        NSString *strDateBirthday = [NSString stringWithFormat:@"%@-%@-%@",self.lbSelectYearBirthday.text, self.lbSelectMonthBirthday.text, self.lbSelectDayBirthday.text];
        if (![Validator isTheStringDate:strDateBirthday]) {
            isValidationPass = FALSE;
            self.lbTextBirthday.textColor = [UIColor redColor];
        }
    }
    if (![self.txtFieldFirstMail.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldLastMail.text isEqualToString:K_STRING_EMPTY]) {
        NSString *stringEmail = [NSString stringWithFormat:@"%@@%@",self.txtFieldFirstMail.text,self.txtFieldLastMail.text];
        if (![Validator isAllHalfWidthCharacter:self.txtFieldFirstMail.text] ||
            ![Validator isAllHalfWidthCharacter:self.txtFieldLastMail.text] ||
            ![Validator validateEmail:stringEmail]) {
            
            isValidationPass = FALSE;
            self.lbTextEmail.textColor = [UIColor redColor];
        }
    }
    
    return isValidationPass;
}
- (BOOL)isExistData
{
    if (![self.txtFieldFirstNameKanji.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldLastNameKanji.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldFirstNameHiragana.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldLastNameHiragana.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldNameYobidashi.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldFirstPostNumber.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldLastPostNumber.text isEqualToString:K_STRING_EMPTY] ||
        ![self.lbPrefecturesName.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldCityName.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldTownName.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldAreaName.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldBuildingName.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldFirstPhoneNumber.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldMidPhoneNumber.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldLastPhoneNumber.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldFirstMobileNumber.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldMidMobileNumber.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldLastMobileNumber.text isEqualToString:K_STRING_EMPTY] ||
        ![self.lbSelectYearBirthday.text isEqualToString:K_STRING_EMPTY] ||
        ![self.lbSelectMonthBirthday.text isEqualToString:K_STRING_EMPTY] ||
        ![self.lbSelectDayBirthday.text isEqualToString:K_STRING_EMPTY] ||
        gender == 1 || gender == 2 ||
        ![self.txtFieldFirstMail.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldLastMail.text isEqualToString:K_STRING_EMPTY] ||
        ![self.txtFieldPassword.text isEqualToString:K_STRING_EMPTY]) {
        return YES;
    }
    return NO;
}
#pragma mark ---- NSXMLParserDelegate method implementation -----
-(void)parserDidStartDocument:(NSXMLParser *)parser{
    self.arrAddressData = [[NSMutableArray alloc] init];
}

-(void)parserDidEndDocument:(NSXMLParser *)parser{
    if ([self.arrAddressData count] > 0) {
        NSDictionary *dictAddress = [self.arrAddressData objectAtIndex:0];
        self.lbPrefecturesName.text = [dictAddress objectForKey:kXmlState];
        self.txtFieldCityName.text = [dictAddress objectForKey:kXmlCity];
        self.txtFieldTownName.text = [dictAddress objectForKey:kXmlAddress];
    }else
    {
        [Util showMessage:ALERT_MSG_NO_RESULT_WITH_ZIPCODE withTitle:LB_ALERT_TITLE_ERR];
    }
}

-(void)parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError{
    NSLog(@"%@", [parseError localizedDescription]);
}

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{
    
    if ([elementName isEqualToString:kXmlAddressValue]) {
        self.dictTempData = [[NSMutableDictionary alloc] init];
    }else if ([elementName isEqualToString:kXmlValue]){
        NSString *state_kana = [attributeDict objectForKey:kXmlStateKana];
        if (state_kana) {
            [self.dictTempData setObject:state_kana forKey:kXmlStateKana];
        }
        NSString *city_kana = [attributeDict objectForKey:kXmlCityKana];
        if (city_kana) {
            [self.dictTempData setObject:city_kana forKey:kXmlCityKana];
        }
        NSString *address_kana = [attributeDict objectForKey:kXmlAddressKana];
        if (address_kana) {
            [self.dictTempData setObject:address_kana forKey:kXmlAddressKana];
        }
        
        NSString *state = [attributeDict objectForKey:kXmlState];
        if (state) {
            [self.dictTempData setObject:state forKey:kXmlState];
        }
        NSString *city = [attributeDict objectForKey:kXmlCity];
        if (city) {
            [self.dictTempData setObject:city forKey:kXmlCity];
        }
        NSString *address = [attributeDict objectForKey:kXmlAddress];
        if (address) {
            [self.dictTempData setObject:address forKey:kXmlAddress];
        }

    }
}

-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{
    
    if ([elementName isEqualToString:kXmlAddressValue]) {
        [self.arrAddressData addObject:[[NSDictionary alloc] initWithDictionary:self.dictTempData]];
    }
}
#pragma mark ----- Process Error -----
- (void)processErrorCode:(NSInteger)code{
    NSString *msg = [APIClient errorCodeMessageWithCode:code];
    if (msg != nil) {
        [Util showMessage:msg withTitle:LB_ALERT_TITLE_ERR];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
