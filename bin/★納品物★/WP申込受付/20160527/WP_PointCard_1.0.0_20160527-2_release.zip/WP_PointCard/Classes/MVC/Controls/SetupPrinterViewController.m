//
//  SetupPrinterViewController.m
//  PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/13.
//  Copyright (c) 2016年 OA-Center Company. All rights reserved.
//

#import "SetupPrinterViewController.h"
#import "LoginViewController.h"
#import "ShowMsg.h"
#define KEY_RESULT     @"Result"
#define KEY_METHOD     @"Method"
@interface SetupPrinterViewController ()
{
    Epos2Printer *printer_;
    int printerSeries_;
    int lang_;
    NSString *strWarning;
}

@end

@implementation SetupPrinterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    filteroption_  = [[Epos2FilterOption alloc] init];
    [filteroption_ setDeviceType:EPOS2_TYPE_PRINTER];
    printerList_ = [[NSMutableArray alloc]init];

    _printerView_.dataSource = self;
    _printerView_.delegate = self;
    
    printer_ = nil;
    printerSeries_ = EPOS2_TM_M30;
    lang_ = EPOS2_MODEL_JAPANESE;
    strWarning = @"";
    int result = [Epos2Log setLogSettings:EPOS2_PERIOD_TEMPORARY output:EPOS2_OUTPUT_STORAGE ipAddress:nil port:0 logSize:1 logLevel:EPOS2_LOGLEVEL_LOW];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"setLogSettings"];
    }
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    int result = [Epos2Discovery start:filteroption_ delegate:self];
    if (EPOS2_SUCCESS != result) {
        [ShowMsg showErrorEpos:result method:@"start"];
    }
    
    [_printerView_ reloadData];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    int result = EPOS2_SUCCESS;
    
    while (YES) {
        result = [Epos2Discovery stop];
        
        if (result != EPOS2_ERR_PROCESSING) {
            break;
        }
    }
    
    if (printerList_ != nil) {
        [printerList_ removeAllObjects];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    printerList_ = nil;
    filteroption_ = nil;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSInteger rowNumber = 0;
    if (section == 0) {
        rowNumber = [printerList_ count];
    }
    return rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"basis-cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
    }
    
    if (indexPath.section == 0) {
        if (indexPath.row >= 0 && indexPath.row < [printerList_ count]) {
            cell.textLabel.text = [(Epos2DeviceInfo *)[printerList_ objectAtIndex:indexPath.row] getDeviceName];
            cell.detailTextLabel.text = [(Epos2DeviceInfo *)[printerList_ objectAtIndex:indexPath.row] getTarget];
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    if (indexPath.section == 0) {
        NSString *printerAddress = [(Epos2DeviceInfo *)[printerList_ objectAtIndex:indexPath.row] getTarget];
        [Util setObject:printerAddress forKey:kPrinterAddressBluetooth];
    }
}

- (void)onDiscovery:(Epos2DeviceInfo *)deviceInfo
{
    [printerList_ addObject:deviceInfo];
    [_printerView_ reloadData];
}

- (IBAction)restartDiscovery:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    [Util setObject:@"" forKey:kPrinterAddressBluetooth];
    int result = EPOS2_SUCCESS;
    
    while (YES) {
        result = [Epos2Discovery stop];
        
        if (result != EPOS2_ERR_PROCESSING) {
            if (result == EPOS2_SUCCESS) {
                break;
            }
            else {
                [ShowMsg showErrorEpos:result method:@"stop"];
                return;
            }
        }
    }
    
    [printerList_ removeAllObjects];
    [_printerView_ reloadData];
    
    result = [Epos2Discovery start:filteroption_ delegate:self];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"start"];
    }
}
- (IBAction)btnBackLoginClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    LoginViewController *loginVC = [[LoginViewController alloc] initWithNibName:NibLoginVC bundle:nil];
    [Util appDelegate].window.rootViewController = loginVC;
}
- (IBAction)btnTestPrintClick:(id)sender {
    if (![self runPrintReceiptSequence]) {
    }
}



#pragma mark ----- TEST PRINTER -----
- (BOOL)printData
{
    int result = EPOS2_SUCCESS;
    
    Epos2PrinterStatusInfo *status = nil;
    
    if (printer_ == nil) {
        return NO;
    }
    
    if (![self connectPrinter]) {
        return NO;
    }
    
    status = [printer_ getStatus];
    [self dispPrinterWarnings:status];
    
    if (![self isPrintable:status]) {
        [ShowMsg show:[self makeErrorMessage:status]];
        [printer_ disconnect];
        return NO;
    }
    
    result = [printer_ sendData:EPOS2_PARAM_DEFAULT];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"sendData"];
        [printer_ disconnect];
        return NO;
    }
    
    return YES;
}

- (BOOL)initializeObject
{
    printer_ = [[Epos2Printer alloc] initWithPrinterSeries:printerSeries_ lang:lang_];
    
    if (printer_ == nil) {
        [ShowMsg showErrorEpos:EPOS2_ERR_PARAM method:@"initiWithPrinterSeries"];
        return NO;
    }
    
    [printer_ setReceiveEventDelegate:self];
    
    return YES;
}

- (void)finalizeObject
{
    if (printer_ == nil) {
        return;
    }
    
    [printer_ clearCommandBuffer];
    
    [printer_ setReceiveEventDelegate:nil];
    
    printer_ = nil;
}

-(BOOL)connectPrinter
{
    int result = EPOS2_SUCCESS;
    
    if (printer_ == nil) {
        return NO;
    }
    NSString *printerAddress = [Util objectForKey:kPrinterAddressBluetooth];
    if ([printerAddress isEqualToString:@""] || printerAddress == NULL) {
        [Util showMessage:LB_ALERT_MSG_PRINTER_ERR withTitle:LB_ALERT_TITLE_ERR];
        return NO;
    }
    
    result = [printer_ connect:printerAddress timeout:EPOS2_PARAM_DEFAULT];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"connect"];
        return NO;
    }
    
    result = [printer_ beginTransaction];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"beginTransaction"];
        [printer_ disconnect];
        return NO;
    }
    
    return YES;
}


- (BOOL)runPrintReceiptSequence
{
    strWarning = @"";
    
    if (![self initializeObject]) {
        return NO;
    }
    
    if (![self createReceiptData]) {
        [self finalizeObject];
        return NO;
    }
    
    if (![self printData]) {
        [self finalizeObject];
        return NO;
    }
    
    return YES;
}

- (BOOL)createReceiptData
{
    int result = EPOS2_SUCCESS;
    
    if (printer_ == nil) {
        return NO;
    }
    
    NSMutableString *textData = [[NSMutableString alloc] init];
    
    if (textData == nil) {
        return NO;
    }
    
    result = [printer_ addTextLang:EPOS2_LANG_JA];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"addTextLang"];
        return NO;
    }
    
    result = [printer_ addTextAlign:EPOS2_ALIGN_CENTER];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"addTextAlign"];
        return NO;
    }
    
    // Add point card string
    result = [printer_ addTextSize:2 height:2];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"addTextSize"];
        return NO;
    }
    
    NSString *nameStore = [NSString stringWithFormat:@"%@\n",[Util objectForKey:kPreferenceCardName]];
    result = [printer_ addText:nameStore];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"addText"];
        return NO;
    }
    
    result = [printer_ addFeedLine:1];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"addFeedLine"];
        return NO;
    }
    
    result = [printer_ addTextSize:1 height:1];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"addTextSize"];
        return NO;
    }
    
    [textData appendString:@"成功\n"];
    result = [printer_ addText:textData];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"addText"];
        return NO;
    }
    [textData setString:@""];

    result = [printer_ addFeedLine:1];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"addFeedLine"];
        return NO;
    }
    
    result = [printer_ addCut:EPOS2_CUT_FEED];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"addCut"];
        return NO;
    }
    
    return YES;
}

- (void)disconnectPrinter
{
    int result = EPOS2_SUCCESS;
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    
    if (printer_ == nil) {
        return;
    }
    
    result = [printer_ endTransaction];
    if (result != EPOS2_SUCCESS) {
        [dict setObject:[NSNumber numberWithInt:result] forKey:KEY_RESULT];
        [dict setObject:@"endTransaction" forKey:KEY_METHOD];
        [self performSelectorOnMainThread:@selector(showEposErrorFromThread:) withObject:dict waitUntilDone:NO];
    }
    
    result = [printer_ disconnect];
    if (result != EPOS2_SUCCESS) {
        [dict setObject:[NSNumber numberWithInt:result] forKey:KEY_RESULT];
        [dict setObject:@"disconnect" forKey:KEY_METHOD];
        [self performSelectorOnMainThread:@selector(showEposErrorFromThread:) withObject:dict waitUntilDone:NO];
    }
    [self finalizeObject];
}

- (void)showEposErrorFromThread:(NSDictionary *)dict
{
    int result = EPOS2_SUCCESS;
    NSString *method = @"";
    result = [[dict valueForKey:KEY_RESULT] intValue];
    method = [dict valueForKey:KEY_METHOD];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:method];
    }
}

- (BOOL)isPrintable:(Epos2PrinterStatusInfo *)status
{
    if (status == nil) {
        return NO;
    }
    
    if (status.connection == EPOS2_FALSE) {
        return NO;
    }
    else if (status.online == EPOS2_FALSE) {
        return NO;
    }
    else {
        ;//print available
    }
    
    return YES;
}

- (void) onPtrReceive:(Epos2Printer *)printerObj code:(int)code status:(Epos2PrinterStatusInfo *)status printJobId:(NSString *)printJobId
{
    if (code != EPOS2_CODE_SUCCESS) {
        [ShowMsg showResult:code errMsg:[self makeErrorMessage:status]];
    }else
    {
        [Util showMessage:@"成功" withTitle:LB_ALERT_TITLE_CARD_NUM_EXIST];
    }
    
    [self dispPrinterWarnings:status];
    
    [self performSelectorInBackground:@selector(disconnectPrinter) withObject:nil];
}

- (void)dispPrinterWarnings:(Epos2PrinterStatusInfo *)status
{
    NSMutableString *warningMsg = [[NSMutableString alloc] init];
    
    if (status == nil) {
        return;
    }
    
    strWarning = @"";
    
    if (status.paper == EPOS2_PAPER_NEAR_END) {
        [warningMsg appendString:k_warn_receipt_near_end];
    }
    
    if (status.batteryLevel == EPOS2_BATTERY_LEVEL_1) {
        [warningMsg appendString:k_warn_battery_near_end];
    }
    
    strWarning = warningMsg;
}

- (NSString *)makeErrorMessage:(Epos2PrinterStatusInfo *)status
{
    NSMutableString *errMsg = [[NSMutableString alloc] initWithString:@""];
    
    if (status.getOnline == EPOS2_FALSE) {
        [errMsg appendString:k_err_offline];
    }
    if (status.getConnection == EPOS2_FALSE) {
        [errMsg appendString:k_err_no_response];
    }
    if (status.getCoverOpen == EPOS2_TRUE) {
        [errMsg appendString:k_err_cover_open];
    }
    if (status.getPaper == EPOS2_PAPER_EMPTY) {
        [errMsg appendString:k_err_receipt_end];
    }
    if (status.getPaperFeed == EPOS2_TRUE || status.getPanelSwitch == EPOS2_SWITCH_ON) {
        [errMsg appendString:k_err_paper_feed];
    }
    if (status.getErrorStatus == EPOS2_MECHANICAL_ERR || status.getErrorStatus == EPOS2_AUTOCUTTER_ERR) {
        [errMsg appendString:k_err_autocutter];
        [errMsg appendString:k_err_need_recover];
    }
    if (status.getErrorStatus == EPOS2_UNRECOVER_ERR) {
        [errMsg appendString:k_err_unrecover];
    }
    
    if (status.getErrorStatus == EPOS2_AUTORECOVER_ERR) {
        if (status.getAutoRecoverError == EPOS2_HEAD_OVERHEAT) {
            [errMsg appendString:k_err_overheat];
            [errMsg appendString:k_err_head];
        }
        if (status.getAutoRecoverError == EPOS2_MOTOR_OVERHEAT) {
            [errMsg appendString:k_err_overheat];
            [errMsg appendString:k_err_motor];
        }
        if (status.getAutoRecoverError == EPOS2_BATTERY_OVERHEAT) {
            [errMsg appendString:k_err_overheat];
            [errMsg appendString:k_err_battery];
        }
        if (status.getAutoRecoverError == EPOS2_WRONG_PAPER) {
            [errMsg appendString:k_err_wrong_paper];
        }
    }
    if (status.getBatteryLevel == EPOS2_BATTERY_LEVEL_0) {
        [errMsg appendString:k_err_battery_real_end];
    }
    
    return errMsg;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
