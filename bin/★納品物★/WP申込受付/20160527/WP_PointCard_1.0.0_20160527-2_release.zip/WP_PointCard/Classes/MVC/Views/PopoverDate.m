//
//  PopoverDate.m
//  WP_PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/10.
//  Copyright © 2016年 OA-Center Company. All rights reserved.
//

#import "PopoverDate.h"

@interface PopoverDate ()

@end

@implementation PopoverDate
- (void)viewDidLoad {
    [super viewDidLoad];
    NSDate *currentDate = [NSDate date];
    NSCalendar* calendar = [NSCalendar currentCalendar];
    NSDateComponents* components = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:currentDate];
    int currentYear = (int)[components year];
    _arrValues = [[NSMutableArray alloc] init];
    switch (self.selectMode) {
        case SELECT_PROVINCE:
        {
            _arrValues = [NSMutableArray arrayWithObjects:@"北海道",@"青森県",@"岩手県",@"宮城県",@"秋田県",@"山形県",@"福島県",@"茨城県",@"栃木県",@"群馬県",@"埼玉県",@"千葉県",
                                                            @"東京都",@"神奈川県",@"新潟県",@"富山県",@"石川県",@"福井県",@"山梨県",@"長野県",@"岐阜県",@"静岡県",@"愛知県",@"三重県",
                                                            @"滋賀県",@"京都府",@"大阪府",@"兵庫県",@"奈良県",@"和歌山県",@"鳥取県",@"島根県",@"岡山県",@"広島県",@"山口県",@"徳島県",
                                                            @"香川県",@"愛媛県",@"高知県",@"福岡県",@"佐賀県",@"長崎県",@"熊本県",@"大分県",@"宮崎県",@"鹿児島県",@"沖縄県", nil];
            self.preferredContentSize = CGSizeMake(POPOVER_PROVINCE_WIDTH, POPOVER_PROVINCE_HEIGHT);
        }
            break;
        case SELECT_YEAR:
        {
            for (int i = 0; i <= AMOUNT_YEAR; i++) {
                int valueYear = currentYear - i;
                [_arrValues addObject:[NSNumber numberWithInt:valueYear]];
            }
            self.preferredContentSize = CGSizeMake(POPOVER_WIDTH, POPOVER_HEIGHT);
        }
            break;
        case SELECT_MONTH:
        {
            for (int i = 1; i <= AMOUNT_MONTH; i++) {
                [_arrValues addObject:[NSNumber numberWithInt:i]];
            }
            self.preferredContentSize = CGSizeMake(POPOVER_WIDTH, POPOVER_HEIGHT);
        }
            break;
        case SELECT_DAY:
        {
            NSString *yearBirthday = [Util objectForKey:kDataYearBirthday];
            NSString *monthBirthday = [Util objectForKey:kDataMonthBirthday];
            if (![yearBirthday isEqualToString:K_STRING_EMPTY] && ![monthBirthday isEqualToString:K_STRING_EMPTY]) {
                [components setYear:[yearBirthday integerValue]];
                [components setMonth:[monthBirthday integerValue]];
                NSDate *date = [calendar dateFromComponents:components];
                NSRange range = [calendar rangeOfUnit:NSCalendarUnitDay inUnit:NSCalendarUnitMonth forDate:date];
                
                for (int i = 1; i <= (int)range.length; i++) {
                    [_arrValues addObject:[NSNumber numberWithInt:i]];
                }
            }else
            {
                for (int i = 1; i <= AMOUNT_DAY; i++) {
                    [_arrValues addObject:[NSNumber numberWithInt:i]];
                }
            }
            self.preferredContentSize = CGSizeMake(POPOVER_WIDTH, POPOVER_HEIGHT);
        }
            break;
        case SELECT_NOTIFI:
        {
            CGSize size = [self initTextNotification];
            if (self.txtFieldTag == TXT_FIELD_PASSWORD) {
               self.preferredContentSize = CGSizeMake(size.width + 50, size.height + 80);
            }else
            {
                self.preferredContentSize = CGSizeMake(size.width + 50, size.height + 30);
            }
            
            [self.tableView setBackgroundColor:[UIColor clearColor]];
            self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        }
            break;
            
        default:
            break;
    }
    self.clearsSelectionOnViewWillAppear = NO;
}
#pragma mark - Init
- (void)viewWillAppear:(BOOL)animated
{
    [[self tableView] reloadData];
}

- (void)viewDidAppear:(BOOL)animated
{
    NSDate *currentDate = [NSDate date];
    NSCalendar* calendar = [NSCalendar currentCalendar];
    NSDateComponents* components = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:currentDate];
    int currentYear = (int)[components year];
    switch (self.selectMode) {
        case SELECT_PROVINCE:
        {
            NSString *hasPref = [Util objectForKey:kDataPrefectureName];
            if (![hasPref isEqualToString:K_STRING_EMPTY]) {
                NSInteger idxRow = [_arrValues indexOfObject:hasPref];
                NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:idxRow inSection:0];
                [self.tableView scrollToRowAtIndexPath:scrollIndexPath atScrollPosition:UITableViewScrollPositionMiddle animated:NO];
            }
        }
            break;
        case SELECT_YEAR:
        {
            int hasYear = [[Util objectForKey:kDataYearBirthday] intValue];
            NSInteger idxRow = 0;
            if (hasYear == 0) {
                NSInteger defaultYear = currentYear;
                idxRow = [_arrValues indexOfObject:@(defaultYear)];
            }else
            {
                idxRow = [_arrValues indexOfObject:@(hasYear)];
            }
            
            NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:idxRow inSection:0];
            [self.tableView scrollToRowAtIndexPath:scrollIndexPath atScrollPosition:UITableViewScrollPositionMiddle animated:NO];
        }
            break;
        case SELECT_MONTH:
        {
            int hasMonth = [[Util objectForKey:kDataMonthBirthday] intValue];
            NSInteger idxRow = [_arrValues indexOfObject:@(hasMonth)];
            NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:idxRow inSection:0];
            [self.tableView scrollToRowAtIndexPath:scrollIndexPath atScrollPosition:UITableViewScrollPositionMiddle animated:NO];
        }
            break;
        case SELECT_DAY:
        {
            int hasDay = [[Util objectForKey:kDataDayBirthday] intValue];
            NSInteger idxRow = [_arrValues indexOfObject:@(hasDay)];
            NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:idxRow inSection:0];
            [self.tableView scrollToRowAtIndexPath:scrollIndexPath atScrollPosition:UITableViewScrollPositionMiddle animated:NO];
        }
            break;
            
        default:
            break;
    }
}

- (CGSize)initTextNotification
{
    UILabel *lbNotifi = [[UILabel alloc] init];
    lbNotifi.font = [UIFont fontWithName:kFontHiraginoGothicW3 size:20.0f];
    switch (self.txtFieldTag) {
        case TXT_FIELD_FIRST_NAME_KANJI:
            lbNotifi.text = kNotifiFirstNameKanji;
            break;
        case TXT_FIELD_LAST_NAME_KANJI:
            lbNotifi.text = kNotifiLastNameKanji;
            break;
        case TXT_FIELD_FIRST_NAME_KANA:
            lbNotifi.text = kNotifiFirstNameKana;
            break;
        case TXT_FIELD_LAST_NAME_KANA:
            lbNotifi.text = kNotifiLastNameKana;
            break;
        case TXT_FIELD_NAME_YOBIDASHI:
            lbNotifi.text = kNotifiNameYobidashi;
            break;
        case TXT_FIELD_FIRST_ZIP_POST:
            lbNotifi.text = kNotifiFirstZipPost;
            break;
        case TXT_FIELD_LAST_ZIP_POST:
            lbNotifi.text = kNotifiLastZipPost;
            break;
        case TXT_FIELD_CITY_NAME:
            lbNotifi.text = kNotifiCityName;
            break;
        case TXT_FIELD_TOWN_NAME:
            lbNotifi.text = kNotifiTownName;
            break;
        case TXT_FIELD_BLOCK_NAME:
            lbNotifi.text = kNotifiBlockName;
            break;
        case TXT_FIELD_BUILDING_NAME:
            lbNotifi.text = kNotifiBuildingName;
            break;
        case TXT_FIELD_FIRST_TEL_NUMBER:
            lbNotifi.text = kNotifiFirstTelNumber;
            break;
        case TXT_FIELD_MID_TEL_NUMBER:
            lbNotifi.text = kNotifiMidTelNumber;
            break;
        case TXT_FIELD_LAST_TEL_NUMBER:
            lbNotifi.text = kNotifiLastTelNumber;
            break;
        case TXT_FIELD_FIRST_MOBILE_NUMBER:
            lbNotifi.text = kNotifiFirstMobileNumber;
            break;
        case TXT_FIELD_MID_MOBILE_NUMBER:
            lbNotifi.text = kNotifiMidMobileNumber;
            break;
        case TXT_FIELD_LAST_MOBILE_NUMBER:
            lbNotifi.text = kNotifiLastMobileNumber;
            break;
        case TXT_FIELD_FIRST_EMAIL:
            lbNotifi.text = kNotifiFirstEmail;
            break;
        case TXT_FIELD_LAST_EMAIL:
            lbNotifi.text = kNotifiLastEmail;
            break;
        case TXT_FIELD_PASSWORD:
            lbNotifi.text = kNotifiPassword1;
            break;
        default:
            break;
    }
    if (self.txtFieldTag == TXT_FIELD_PASSWORD) {
        _arrValues = [NSMutableArray arrayWithObjects:kNotifiPassword1,kNotifiPassword2, nil];
    }else
    {
        _arrValues = [NSMutableArray arrayWithObjects:lbNotifi.text, nil];
    }
    CGSize labelSize = [lbNotifi.text sizeWithAttributes:@{NSFontAttributeName:lbNotifi.font}];
    lbNotifi.frame = CGRectMake(lbNotifi.frame.origin.x, lbNotifi.frame.origin.y,lbNotifi.frame.size.width, labelSize.height);

    return labelSize;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_arrValues count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    [cell.textLabel setTextAlignment:NSTextAlignmentCenter];
    if (self.selectMode == SELECT_PROVINCE) {
        cell.textLabel.text = [_arrValues objectAtIndex:indexPath.row];
    }else if (self.selectMode == SELECT_NOTIFI)
    {
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.font = [UIFont fontWithName:kFontHiraginoMorningW3 size:20.0f];
        cell.textLabel.numberOfLines = 0;
        cell.textLabel.textAlignment = NSTextAlignmentLeft;
        cell.textLabel.text = [_arrValues objectAtIndex:indexPath.row];
    }else
    {
        cell.textLabel.text = [[_arrValues objectAtIndex:indexPath.row] stringValue];
    }
    
    return cell;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([tableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [tableView setSeparatorInset:UIEdgeInsetsZero];
    }
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
   
    if (_delegate != nil) {
        if (self.selectMode == SELECT_PROVINCE) {
             NSString *selectValue = [_arrValues objectAtIndex:indexPath.row];
            [_delegate selectedProvince:selectValue];
        }else
        {
             NSNumber *selectValue = [_arrValues objectAtIndex:indexPath.row];
            [_delegate selectedValue:[selectValue intValue] withMode:self.selectMode];
        }
        
    }
}


@end
