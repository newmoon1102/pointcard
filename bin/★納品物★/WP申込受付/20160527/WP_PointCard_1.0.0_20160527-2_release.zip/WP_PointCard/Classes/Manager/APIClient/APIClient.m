//
//  APIClient.h
//  PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/13.
//  Copyright (c) 2016年 OA-Center Company. All rights reserved.
//
#import "APIClient.h"
#import "ServicesConfig.h"

@implementation APIClient

static APIClient *_sharedClient = nil;
static bool isWaitingPassApi = FALSE;

+ (APIClient *)wpSharedClient {
    NSString *strBaseUrl = [[NSUserDefaults standardUserDefaults] stringForKey:@"kApiWpUrlBase"];
    isWaitingPassApi = TRUE;
    _sharedClient = nil;
    _sharedClient = [[APIClient alloc] initWithBaseURL:[NSURL URLWithString:strBaseUrl]];
    return _sharedClient;
}

+ (APIClient *)registerSharedClient
{
     NSString *strBaseUrl = [[NSUserDefaults standardUserDefaults] stringForKey:@"kApiRegisterUrlBase"];
    isWaitingPassApi = FALSE;
    _sharedClient = nil;
    _sharedClient = [[APIClient alloc] initWithBaseURL:[NSURL URLWithString:strBaseUrl]];
    return _sharedClient;
}

+ (void)destroySharedClient {
    _sharedClient = nil;
}

- (id)initWithBaseURL:(NSURL *)url {
    self = [super initWithBaseURL:url];
    if (!self) {
        return nil;
    }
    self.allowsInvalidSSLCertificate = YES;
    [self registerHTTPOperationClass:[AFHTTPRequestOperation class]];
    return self;
}
+ (NSString *)errorCodeMessageWithCode:(NSInteger)status{
    switch (status) {
        case 1:
            return ALERT_MSG_API_ERR_CODE_1;
        case 2:
            return ALERT_MSG_API_ERR_CODE_2;
        case 3:
            return ALERT_MSG_API_ERR_CODE_3;
        case 4:
            return ALERT_MSG_API_ERR_CODE_4;
        case 5:
            return ALERT_MSG_API_ERR_CODE_5;
        case 6:
            return ALERT_MSG_API_ERR_CODE_6;
        case 400:
            return ALERT_MSG_API_WP_ERR_CODE_400;
        case 401:
            return ALERT_MSG_API_WP_ERR_CODE_401;
        case 404:
            return ALERT_MSG_API_WP_ERR_CODE_404;
        case 500:
            return ALERT_MSG_API_WP_ERR_CODE_500;
        case 503:
            return ALERT_MSG_API_WP_ERR_CODE_503;
        case 1001:
        case -1009:
        case -1004:
        case -1001:
            return ALERT_MSG_API_ERR_CODE_1001;
        case -1011:
            return ALERT_MSG_API_ERR_CODE_1011;
        case -1002:
            return ALERT_MSG_API_ERR_CODE_1002;

        default:
            break;
    }
    return nil;
}

// The function paser data when request success and return data in block
- (void)completeRequestOperation:(AFHTTPRequestOperation *)operation
                        withData:(id)responseData
                           error:(NSError *)err
                      completion:(void(^)(ResponseObject *))completion
{
     NSLog(@"--- url: %@",operation.request.URL);
    if(err){
        // DLog(@"Error: %@",err);
        [self handleRequestError:err completion:completion];
    }else{
        ResponseObject *obj = [[ResponseObject alloc] init];
        if(responseData){
            NSError *errorPaser = nil;
             NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
             NSLog(@"%@",str);
            id responseDict = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&errorPaser];
            if(errorPaser){
                obj.statusCode = status_api_parser_error;
            }else{
                int status;
                if (isWaitingPassApi) {
                    status = [[responseDict objectForKey:kApiCode] intValue];
                }else
                {
                    status = [[responseDict objectForKey:kApiStatus] intValue];
                }
                
                id data = responseDict;
                id correctData = data;
                if([data isKindOfClass:[NSDictionary class]]){
                    correctData = [NSMutableDictionary dictionary];
                    NSArray *keyArray = [data allKeys];
                    for (NSString *key in keyArray) {
                        id obj = [data objectForKey:key];
                        if([obj isKindOfClass:[NSNull class]])
                            obj = @"";
                        [correctData setObject:obj forKey:key];
                    }
                }else if([data isKindOfClass:[NSArray class]]){
                    correctData = [NSMutableArray array];
                    for (NSDictionary *dic in data) {
                        NSMutableDictionary *nDict = [NSMutableDictionary dictionary];
                        NSArray *keyArray = [dic allKeys];
                        for (NSString *key in keyArray) {
                            id obj = [dic objectForKey:key];
                            if([obj isKindOfClass:[NSNull class]])
                                obj = @"";
                            [nDict setObject:obj forKey:key];
                        }
                        [correctData addObject:nDict];
                    }
                }
                obj.data = correctData;
                obj.statusCode = status;
            }
        }
        completion(obj);
    }
}

 // The function process return object contain error when request fail
- (void)handleRequestError:(NSError *)error completion:(void(^)(ResponseObject *))completion{
    if (completion) {
        ResponseObject *obj = [[ResponseObject alloc] init];
        [obj setStatusCode:(int)[error code]];
        [obj setMessage:[error localizedDescription]];
        [obj setData:nil];
        completion(obj);
    }
}
// The function request with params
- (void)requestWithPostPath:(NSString *)postPath withParams:(NSDictionary *)params completion:(ApiCompletion)block{
    [self postPath:postPath parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [self completeRequestOperation:operation withData:responseObject error:nil completion:block];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [self completeRequestOperation:operation withData:nil error:error completion:block];
    }];
}

// -------------------------------------- WP server -------------------------------------------------
- (void)login:(NSString *)userID password:(NSString *)pw completion:(ApiCompletion)block
{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:userID forKey:kParamLogin];
    [params setObject:pw forKey:kParamPassword];
    [self requestWithPostPath:@"shop/auth" withParams:params completion:block];
}

- (void)getUserInfoWithShopAuthCode:(NSString *)shopAuthCode qrCode:(NSString *)qrCode completion:(ApiCompletion)block
{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:shopAuthCode forKey:kParamShopAuthCode];
    [params setObject:qrCode forKey:kParamMemberQrCode];
    [self requestWithPostPath:@"member/get" withParams:params completion:block];
}
- (void)checkExistEmailWithShopAuthCode:(NSString *)shopAuthCode email:(NSString *)email completion:(ApiCompletion)block
{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:shopAuthCode forKey:kParamShopAuthCode];
    [params setObject:email forKey:kParamMemberEmail];
    [self requestWithPostPath:@"member/search" withParams:params completion:block];
}

// --------------------------------------- Register Server -------------------------------------------
- (void)sendData:(NSString *)strJson completion:(ApiCompletion)block
{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:@"setMember" forKey:kApiMethodId];
    [params setObject:strJson forKey:kApiJsonData];
    [self requestWithPostPath:@"register" withParams:params completion:block];
}
@end
