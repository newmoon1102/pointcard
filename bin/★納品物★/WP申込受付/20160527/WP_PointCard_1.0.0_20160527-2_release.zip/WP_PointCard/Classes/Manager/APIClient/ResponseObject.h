//
//  ResponseObject.h
//  PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/13.
//  Copyright (c) 2016年 OA-Center Company. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ServicesConfig.h"
@interface ResponseObject : NSObject

@property (nonatomic, strong) id data;
@property (nonatomic, assign) int statusCode;
@property (nonatomic, strong) NSString *message;

@end
