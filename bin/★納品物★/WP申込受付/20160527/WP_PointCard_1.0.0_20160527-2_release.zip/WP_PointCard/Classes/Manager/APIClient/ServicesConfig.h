//
//  ServicesConfig.h
//  PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/13.
//  Copyright (c) 2016年 OA-Center Company. All rights reserved.
//

typedef enum{
    status_api_ok = 0,
    status_api_wp_ok = 200,
    status_api_wp_no_data = 404,
    status_api_parser_error = 1001,
    status_api_connect_failed = -1001
} status_code;

#define kApiMethodId        @"methodId"
#define kApiJsonData        @"member_data"

#define kParamLogin         @"login_id"
#define kParamPassword      @"password"
#define kParamShopAuthCode  @"shop_auth_code"
#define kParamMemberQrCode  @"member_qr_code"
#define kParamMemberEmail   @"mail_address"
#define kParamWithDataFlag  @"with_data_flag"

#define kApiNote            @"note"
#define kApiCode            @"code"
#define kApiStatus          @"status"

