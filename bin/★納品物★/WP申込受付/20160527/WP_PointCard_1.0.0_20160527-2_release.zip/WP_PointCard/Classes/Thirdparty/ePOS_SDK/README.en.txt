=========================================================================
          Epson ePOS SDK for iOS Version 2.0.0

          Copyright Seiko Epson Corporation 2015 All rights reserved.
=========================================================================

1. About this software

The Epson ePOS SDK for iOS is an SDK aimed at development engineers who 
are developing iOS applications for printing on an EPSON TM printer and 
an EPSON TM-Intelligent printer.
Applications are developed using the APIs provided by Epson ePOS SDK.
Epson ePOS SDK for Android for Android devices is also provided in 
Epson ePOS SDK.
For detailed information, please see Epson ePOS SDK for iOS User's Manual.

iOS Versions
  iOS 6.0 to 6.1.6
  iOS 7.0 to 7.1.2
  iOS 8.0 to 8.0.2
  iOS 8.2 to 8.4.1
  iOS 9.0 to 9.0.2

iOS Devices
  iPhone ( 4S / 5 / 5c / 5s / 6 / 6 Plus / 6s / 6s Plus )
  iPod touch ( 5th generation / 6th generation )
  iPad2 / iPad ( 3rd generation / 4th generation ) / iPad Air / iPad Air 2
  iPad mini / iPad mini 2 (iPad mini with Retina display) / iPad mini 3
   / iPad mini 4

Supported TM Printers
  EPSON TM-T20
  EPSON TM-T20II
  EPSON TM-T70
  EPSON TM-T70II
  EPSON TM-T81II
  EPSON TM-T82
  EPSON TM-T82II
  EPSON TM-T88V
  EPSON TM-T90II
  EPSON TM-P20
  EPSON TM-P60
  EPSON TM-P60II
  EPSON TM-P80
  EPSON TM-U220 series
  EPSON TM-U330 series
  EPSON TM-m10
  EPSON TM-m30

Supported TM-Intelligent Printers
  EPSON TM-T20II-i
  EPSON TM-T70-i
  EPSON TM-T82II-i
  EPSON TM-T83II-i
  EPSON TM-T88V-i
  EPSON TM-U220-i
  EPSON TM-T70II-DT
  EPSON TM-T88V-DT
  EPSON TM-H6000IV-DT

Supported Interfaces
 TM Printer
  Wired LAN
  Wireless LAN
  Bluetooth
 TM-Intelligent Printer
  Wired LAN

2. Supplied Files

- ePOS2.h
  Header file that includes class definitions and error value / device type 
  constant definitions.

- ePOSEasySelect.h
  Header file for selecting a printer easily.

- libepos2.a
  Library for function execution. 
    (armv7, armv7s, arm64, i386, x86_64 supported)

- libeposeasyselect.a
  Library for selecting a printer easily.
    (armv7, armv7s, arm64, i386, x86_64 supported)

- ePOS_SDK_Sample_iOS.zip
  A sample program file.

- EULA.en.txt
  Contains the SOFTWARE LICENSE AGREEMENT.

- EULA.ja.txt
  Contains the SOFTWARE LICENSE AGREEMENT. (The Japanese-language edition)

- ePOS_SDK_iOS_um_en_revA.pdf
  A user's manual.

- ePOS_SDK_iOS_um_ja_revA.pdf
  A user's manual. (The Japanese-language edition)

- ePOS_SDK_iOS_Migration_Guide_en_revA.pdf
  A Migration guide

- ePOS_SDK_iOS_Migration_Guide_ja_revA.pdf
  A Migration guide (The Japanese-language edition)

- README.en.txt
  This file.

- README.ja.txt
  The Japanese-language edition of this file.

3. Remarks
- For detailed information, please see Epson ePOS SDK for iOS User's Manual.

4. Restriction
  Discovery function of TM-i and TM-DT doesn't work correctly.

5. Version History
  Version 2.0.0
    - New release

