//
//  Constants.h
//  PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/13.
//  Copyright (c) 2016年 OA-Center Company. All rights reserved.
typedef enum
{
    SELECT_PROVINCE = 0,
    SELECT_YEAR     = 1,
    SELECT_MONTH    = 2,
    SELECT_DAY      = 3,
    SELECT_NOTIFI   = 4
    
} SELECT_POPOVER;

typedef enum {
    NEW_MEMBER      = 1,
    OLD_MEMBER      = 2
} MEMBER_TYPE;

typedef enum {
    TXT_FIELD_FIRST_NAME_KANJI      = 1,
    TXT_FIELD_LAST_NAME_KANJI       = 2,
    TXT_FIELD_FIRST_NAME_KANA       = 3,
    TXT_FIELD_LAST_NAME_KANA        = 4,
    TXT_FIELD_NAME_YOBIDASHI        = 5,
    TXT_FIELD_FIRST_ZIP_POST        = 6,
    TXT_FIELD_LAST_ZIP_POST         = 7,
    TXT_FIELD_CITY_NAME             = 8,
    TXT_FIELD_TOWN_NAME             = 9,
    TXT_FIELD_BLOCK_NAME            = 10,
    TXT_FIELD_BUILDING_NAME         = 11,
    TXT_FIELD_FIRST_TEL_NUMBER      = 12,
    TXT_FIELD_MID_TEL_NUMBER        = 13,
    TXT_FIELD_LAST_TEL_NUMBER       = 14,
    TXT_FIELD_FIRST_MOBILE_NUMBER   = 15,
    TXT_FIELD_MID_MOBILE_NUMBER     = 16,
    TXT_FIELD_LAST_MOBILE_NUMBER    = 17,
    TXT_FIELD_FIRST_EMAIL           = 18,
    TXT_FIELD_LAST_EMAIL            = 19,
    TXT_FIELD_PASSWORD              = 20
} TXT_FIELD_TYPE;

#define POPOVER_HEIGHT                      260.0f
#define POPOVER_WIDTH                       120.0f
#define POPOVER_PROVINCE_HEIGHT             350.0f
#define POPOVER_PROVINCE_WIDTH              200.0f
#define ANIMATION_HEIGHT                    120.0f

#define TIME_DURATION_LONG_PRESS_GESTURE    5.0f

#define LB_STANDARD_COLOR                   51
#define AMOUNT_NUMBER_THREE                 3
#define AMOUNT_NUMBER_FOUR                  4
#define AMOUNT_NUMBER_FIVE                  5
#define AMOUNT_TWENTY_CHARACTER             20
#define AMOUNT_FIFTY_CHARACTER              50
#define AMOUNT_ONE_HUNDER_CHARACTER         100
#define AMOUNT_TWO_HUNDER_FIFTY_SIX_CHAR    256
#define AMOUNT_YEAR                         150
#define AMOUNT_MONTH                        12
#define AMOUNT_DAY                          31

// API Get Address
#define kApiUrlGetAddress                   @"http://zip2.cgis.biz/xml/zip.php?zn="
#define kXmlAddressValue                    @"ADDRESS_value"
#define kXmlValue                           @"value"
#define kXmlStateKana                       @"state_kana"
#define kXmlCityKana                        @"city_kana"
#define kXmlAddressKana                     @"address_kana"
#define kXmlState                           @"state"
#define kXmlCity                            @"city"
#define kXmlAddress                         @"address"

// End API address

// API Authorization
#define kJsonTenantId                       @"tenant_id"
#define kJsonShopId                         @"shop_id"
#define kJsonShopAuthCode                   @"shop_auth_code"
#define kJsonShopName                       @"shop_name"

#define kJsonMemberId                       @"member_id"
#define kJsonReceiptDate                    @"receipt_date"
#define kJsonMemberType                     @"member_type"
#define kJsonCardNo                         @"card_no"
#define kJsonPoint                          @"point"
#define kJsonFirstNameKanji                 @"first_name"
#define kJsonLastNameKanji                  @"last_name"
#define kJsonFirstNameKana                  @"first_name_y"
#define kJsonLastNameKana                   @"last_name_y"
#define kJsonNameYobidashi                  @"call_name"
#define kJsonFirstPostNumber                @"zip_1"
#define kJsonLastPostNumber                 @"zip_2"
#define kJsonPrefName                       @"pref_name"
#define kJsonCityName                       @"area_name"
#define kJsonTownName                       @"city_name"
#define kJsonAreaName                       @"block"
#define kJsonBuildingName                   @"building"
#define kJsonFirstTelNumber                 @"tel_number_1"
#define kJsonMidTelNumber                   @"tel_number_2"
#define kJsonLastTelNumber                  @"tel_number_3"
#define kJsonFirstMobileNumber              @"mobile_number_1"
#define kJsonMidMobileNumber                @"mobile_number_2"
#define kJsonLastMobileNumber               @"mobile_number_3"
#define kJsonFirstOtherTelNumber            @"other_tel_number_1"
#define kJsonMidOtherTelNumber              @"other_tel_number_2"
#define kJsonLastOtherTelNumber             @"other_tel_number_3"
#define kJsonEmailAddress                   @"mail_address"
#define kJsonPassword                       @"password"
#define kJsonGender                         @"sex"
#define kJsonBirthDay                       @"birth"
#define kJsonSendMaganizeMail               @"mailmaga_disable_flag"
#define kJsonSendDirectMail                 @"dm_disable_flag"


// End API Authorization
#define kFirstUrlWaitingPass                @"『 http://www.waitingpass.com/"
#define kLastUrlWaitingPass                 @"/ 』"
#define K_STRING_EMPTY                      @""
#define K_STRING_NUMBER_IPAD                @"0123456789"

// New message
#define LB_ALERT_TITLE_CONFIRM              @"確認"
#define LB_ALERT_MSG_BACK_TOP               @"入力中の項目があります。申し込みを終了しますか?"
#define LB_ALERT_MSG_BACK_LOGIN             @"ログイン画面に戻りますか?"
#define LB_MB_VERIFY_USER_DATA              @"確認中・・・"
#define LB_MB_LOAD_ADDRESS_DATA             @"ご住所を読み込んでいます・・・"
#define LB_ALERT_TITLE_CARD_NUM_EXIST       @"メッセージ"

#define ALERT_MSG_EMAIL_EXIST               @"入力されたメールアドレスはすでに登録済みです。\n追加申込からお申込ください。"
#define ALERT_FIRST_MSG_CARD_NUM_EXIST      @"既にポイントカードが作成済です。\nカード番号「"
#define ALERT_LAST_MSG_CARD_NUM_EXIST       @"」です。\nスタッフまでお申し付けください。"
#define ALERT_MSG_NO_RESULT_WITH_ZIPCODE    @"該当する住所は見つかりませんでした。"

// Confirm 2016/05/20
#define LB_MB_LOGIN                         @"ログイン中・・・"
#define LB_NOTIFI_SETUP_PRINTER             @"ログイン前にプリンターを設定してください。"
#define LB_MB_AUTHO_QR                      @"QR情報を読み込んでいます・・・"
#define LB_MB_SEND_DATA                     @"ユーザー情報を送信中・・・"
#define LB_ALERT_TITLE_ERR                  @"エラー"
#define LB_ALERT_MSG_PRINTER_ERR            @"プリンタ接続エラーです。プリンタの電源またはケーブルの接続をご確認ください。"

#define LB_ALERT_BTN_OK                     @"はい"
#define LB_ALERT_BTN_CANCEL                 @"キャンセル"

#define ALERT_MSG_ID_ERR                    @"店舗IDを入力してください。"
#define ALERT_MSG_PASS_ERR                  @"パスワードを入力してください。"
#define ALERT_MSG_ID_PASS_ERR               @"店舗IDまたはパスワードを入力してください。"
#define ALERT_MSG_ZIPCODE_ERR               @"郵便番号が違います。"
#define ALERT_MSG_ZIPCODE_EMPTY_ERR         @"郵便番号が必須です。"
#define ALERT_MSG_VALIDATE_ERR              @"赤色の項目を見直してください。"
#define ALERT_MSG_QR_CODE_ERR               @"QRコードが違います。正しいQRコードを読み込ませて下さい。"

#define ALERT_MSG_API_WP_LOGIN_ERR          @"店舗IDまたはパスワードが違います。"
#define ALERT_MSG_API_WP_ERR_CODE_400       @"リクエストパラメタに問題があります"
#define ALERT_MSG_API_WP_ERR_CODE_401       @"認証コードに問題があります"
#define ALERT_MSG_API_WP_ERR_CODE_404       @"対象データが存在しません"
#define ALERT_MSG_API_WP_ERR_CODE_500       @"内部エラーにより現在利用できません"
#define ALERT_MSG_API_WP_ERR_CODE_503       @"APIのメンテナンス中により一時的に利用できません"
#define ALERT_MSG_API_ERR_CODE_1            @"データベースとの通信に失敗しました。"
#define ALERT_MSG_API_ERR_CODE_2            @"データベースとの接続に失敗しました。"
#define ALERT_MSG_API_ERR_CODE_3            @"パラメータがありません。"
#define ALERT_MSG_API_ERR_CODE_4            @"サーバーAPIの呼び出しに失敗しました。"
#define ALERT_MSG_API_ERR_CODE_5            @"サーバーAPIでエラーが発生しました。"
#define ALERT_MSG_API_ERR_CODE_6            @"アプリの初期データが存在していません。"
#define ALERT_MSG_API_ERR_CODE_10           @"ログアウトができません。ログイン画面に戻りますか？"
#define ALERT_MSG_API_ERR_CODE_11           @"ログインされていません。"
#define ALERT_MSG_API_ERR_CODE_1001         @"サーバーとの通信がタイムアウトしました。"
#define ALERT_MSG_API_ERR_CODE_1011         @"URLが不正です。"
#define ALERT_MSG_API_ERR_CODE_1002         @"URLが不明です。"

#define kNotifiFirstNameKanji               @"お名前（姓）を「漢字」で入力します"
#define kNotifiLastNameKanji                @"お名前（名）を「漢字」で入力します"
#define kNotifiFirstNameKana                @"おなまえ（せい）を「ひらがな」で入力します"
#define kNotifiLastNameKana                 @"おなまえ（めい）を「ひらがな」で入力します"
#define kNotifiNameYobidashi                @"お呼び出しするさいのお名前を「ひらがな」で入力します"
#define kNotifiFirstZipPost                 @"郵便番号の上３桁を「数字」で入力します"
#define kNotifiLastZipPost                  @"郵便番号の下４桁を「数字」で入力します"
#define kNotifiCityName                     @"市区町村を入力します"
#define kNotifiTownName                     @"町域を入力します"
#define kNotifiBlockName                    @"番地を入力します"
#define kNotifiBuildingName                 @"建物名〜号室を入力します"
#define kNotifiFirstTelNumber               @"ご自宅の電話番号の市外局番を「数字」で入力します"
#define kNotifiMidTelNumber                 @"ご自宅の電話番号の市内局番を「数字」で入力します"
#define kNotifiLastTelNumber                @"ご自宅の電話番号の加入者番号を「数字」で入力します"
#define kNotifiFirstMobileNumber            @"携帯の電話番号の市外局番を「数字」で入力します"
#define kNotifiMidMobileNumber              @"携帯の電話番号の市内局番を「数字」で入力します"
#define kNotifiLastMobileNumber             @"携帯の電話番号の加入者番号を「数字」で入力します"
#define kNotifiFirstEmail                   @"メールアドレスの＠より前の部分を「半角英数字」で入力します"
#define kNotifiLastEmail                    @"メールアドレスの＠より後ろの部分を「半角英数字」で入力します"
#define kNotifiPassword1                    @"パスワードを８文字以上・２０文字以内で「半角英数字」で入力します。"
#define kNotifiPassword2                    @"記号は使用できません。"

#define kReceiptText_1                      @"申込受付票\n"
#define kReceiptText_2                      @"[受付番号　："
#define kReceiptText_3                      @"[お名前　："
#define kReceiptText_4                      @"※カードはレジにて発行します\n"
#define kReceiptText_5                      @"こちらの受付票をレジまで   \n"
#define kReceiptText_6                      @"お待ちください。          \n"

#define k_methoderr_errcode                 @"エラーコード"
#define k_methoderr_method                  @"メソッド"
#define k_statusmsg_result                  @"結果"
#define k_statusmsg_description             @"説明"

#define k_warn_receipt_near_end             @"ロール紙がまもなくなくなります。"
#define k_warn_battery_near_end             @"プリンターの電池残量が低下しています。"
#define k_err_offline                       @"プリンターがオフラインです。"
#define k_err_no_response                   @"プリンターとiPadの通信を確認してください。"
#define k_err_cover_open                    @"プリンターの用紙カバーを閉じてください。"
#define k_err_paper_feed                    @"プリンターの用紙送りボタンを操作してください。"
#define k_err_autocutter                    @"紙詰まりを取り除いてください。"
#define k_err_need_recover                  @"問題が解決しないとき、プリンターの電源を入れなおしてください。"
#define k_err_unrecover                     @"プリンターの電源を入れなおしてください。"
#define k_err_receipt_end                   @"ロール紙を確認してください。"
#define k_err_battery                       @"プリンターの電池が高温になっています。"
#define k_err_overheat                      @"プリンターの警告LEDが消えるまでお待ちください。"
#define k_err_head                          @"プリンターの印字ヘッダーが高温になっています。"
#define k_err_motor                         @"プリンターの制御ICが高温になっています。"
#define k_err_wrong_paper                   @"正しいロール紙をセットしてください。"
#define k_err_battery_real_end              @"プリンターの電池が残りわずかです。ACアダプタを接続するか、充電してください。"

#define MSG_PRINTER_SUCCESS                 @"SUCCESS"
#define MSG_PRINTER_ERR_PARAM               @"ERR_PARAM"
#define MSG_PRINTER_ERR_CONNECT             @"ERR_CONNECT"
#define MSG_PRINTER_ERR_TIMEOUT             @"ERR_TIMEOUT"
#define MSG_PRINTER_ERR_MEMORY              @"ERR_MEMORY"
#define MSG_PRINTER_ERR_ILLEGAL             @"ERR_ILLEGAL"
#define MSG_PRINTER_ERR_PROCESSING          @"ERR_PROCESSING"
#define MSG_PRINTER_ERR_NOT_FOUND           @"ERR_NOT_FOUND"
#define MSG_PRINTER_ERR_IN_USER             @"ERR_IN_USE"
#define MSG_PRINTER_ERR_TYPE_INVALID        @"ERR_TYPE_INVALID"
#define MSG_PRINTER_ERR_DISCONNECT          @"ERR_DISCONNECT"
#define MSG_PRINTER_ERR_ALREADY_OPENED      @"ERR_ALREADY_OPENED"
#define MSG_PRINTER_ERR_ALREADY_USED        @"ERR_ALREADY_USED"
#define MSG_PRINTER_ERR_BOX_COUNT_OVER      @"ERR_BOX_COUNT_OVER"
#define MSG_PRINTER_ERR_BOX_CLIENT_OVER     @"ERR_BOX_CLIENT_OVER"
#define MSG_PRINTER_ERR_UNSUPPORTED         @"ERR_UNSUPPORTED"
#define MSG_PRINTER_ERR_FAILURE             @"ERR_FAILURE"
#define MSG_PRINTER_ERR_CANCEL              @"ERR_CANCEL"
#define MSG_PRINTER_ERR_ALREADY_CONNECT     @"ERR_ALREADY_CONNECT"
#define MSG_PRINTER_ERR_ILLEGAL_DEVICE      @"ERR_ILLEGAL_DEVICE"
#define MSG_PRINTER_PRINT_SUCCESS           @"PRINT_SUCCESS"
#define MSG_PRINTER_PRINTING                @"PRINTING"
#define MSG_PRINTER_ERR_AUTORECOVER         @"ERR_AUTORECOVER"
#define MSG_PRINTER_ERR_COVER_OPEN          @"ERR_COVER_OPEN"
#define MSG_PRINTER_ERR_CUTTER              @"ERR_CUTTER"
#define MSG_PRINTER_ERR_MECHANICAL          @"ERR_MECHANICAL"
#define MSG_PRINTER_ERR_EMPTY               @"ERR_EMPTY"
#define MSG_PRINTER_ERR_UNRECOVERABLE       @"ERR_UNRECOVERABLE"
#define MSG_PRINTER_ERR_SYSTEM              @"ERR_SYSTEM"
#define MSG_PRINTER_ERR_PORT                @"ERR_PORT"
#define MSG_PRINTER_ERR_JOB_NOT_FOUND       @"ERR_JOB_NOT_FOUND"
#define MSG_PRINTER_ERR_SPOOLER             @"ERR_SPOOLER"
#define MSG_PRINTER_ERR_BATTERY_LOW         @"ERR_BATTERY_LOW"


#define kStrGenderIsMale                    @"男性"
#define kStrGenderIsFemale                  @"女性"
#define kStrAllowSendMagazineEmail          @"希望する"
#define kStrNotAllowSendMagazineEmail       @"希望しない"
#define kStrAllowSendDirectEmail            @"希望する"
#define kStrNotAllowSendDirectEmail         @"希望しない"
#define kSoundButton                        @"soundBtn.wav"
#define kSoundScanQR                        @"beep.mp3"

#define kIMG_RADIO_GRAY                     @"radio_gray.png"
#define kIMG_RADIO_GREEN                    @"radio_green.png"
#define kIMG_CHECKED_GRAY                   @"checked_gray.png"
#define kIMG_CHECKED_GREEN                  @"checked_green.png"
#define kIMG_STAR_RED                       @"star_red.png"
#define kIMG_GIVE_WAY_BLACK                 @"give_way_black.png"
#define kIMG_BGR_THANK_VIEW                 @"bgr_thank.png"
#define kIMG_BGR_THANK_VIEW_PRINT           @"bgr_thank_print.png"

#define NibLoginVC                          @"LoginViewController"
#define NibSetupVC                          @"SetupPrinterViewController"
#define NibTopVC                            @"TopViewController"
#define NibRegisterVC                       @"RegisterViewController"
#define NibRegisterQRVC                     @"RegisterQRViewController"
#define NibQRVC                             @"QRViewController"
#define NibConfirmVC                        @"ConfirmViewController"
#define NibConfirmQRVC                      @"ConfirmQrViewController"
#define NibInfoVC                           @"InfoViewController"

#define kPrinterAddressBluetooth            @"PrinterAddressBluetooth"

// Data
#define kDataMemberId                       @"kDataMemberId"
#define kDataFirstNameKanji                 @"kDataFirstNameKanji"
#define kDataLastNameKanji                  @"kDataLastNameKanji"
#define kDataFirstNameHiragana              @"kDataFirstNameHiragana"
#define kDataLastNameHiragana               @"kDataLastNameHiragana"
#define kDataNameYobidashi                  @"kDataNameYobidashi"
#define kDataFirstPostNumber                @"kDataFirstPostNumber"
#define kDataLastPostNumber                 @"kDataLastPostNumber"
#define kDataPrefectureName                 @"kDataPrefectureName"
#define kDataCityName                       @"kDataCityName"
#define kDataTownName                       @"kDataTownName"
#define kDataAreaName                       @"kDataAreaName"
#define kDataBuildingName                   @"kDataBuildingName"
#define kDataFirstHomePhoneNumber           @"kDataFirstHomePhoneNumber"
#define kDataMidHomePhoneNumber             @"kDataMidHomePhoneNumber"
#define kDataLastHomePhoneNumber            @"kDataLastHomePhoneNumber"
#define kDataFirstMobilePhoneNumber         @"kDataFirstMobilePhoneNumber"
#define kDataMidMobilePhoneNumber           @"kDataMidMobilePhoneNumber"
#define kDataLastMobilePhoneNumber          @"kDataLastMobilePhoneNumber"
#define kDataFirstOtherTelNumber            @"kDataFirstOtherTelNumber"
#define kDataMidOtherTelNumber              @"kDataMidOtherTelNumber"
#define kDataLastOtherTelNumber             @"kDataLastOtherTelNumber"
#define kDataYearBirthday                   @"kDataYearBirthday"
#define kDataMonthBirthday                  @"kDataMonthBirthday"
#define kDataDayBirthday                    @"kDataDayBirthday"
#define kDataGender                         @"kDataGender"
#define kDataFirstEmail                     @"kDataFirstEmail"
#define kDataLastEmail                      @"kDataLastEmail"
#define kDataPassWord                       @"kDataPassWord"
#define kDataAllowSendMagazineEmail         @"kDataAllowSendMagazineEmail"
#define kDataAllowSendDirectEmail           @"kDataAllowSendDirectEmail"

// NSUserDefault
#define kDataUserDefaultMemberType          @"kDataUserDefaultMemberType"
#define kDataUserDefaultTenantId            @"kDataUserDefaultTenantId"
#define kDataUserDefaultShopId              @"kDataUserDefaultShopId"
#define kDataUserDefaultShopAuthCode        @"kDataUserDefaultShopAuthCode"
#define kDataUserDefaultShopName            @"kDataUserDefaultShopName"
#define kDataUserDefaultReceiptId           @"kDataUserDefaultReceiptId"

// Preference
#define kPreferenceCardName                 @"card_name_preference"
#define kPreferenceMaimonSushi              @"maimon_sushi_preference"
#define kPreferenceEnablePrinter            @"enabled_printer_preference"
#define kPreferenceEnableValidateAddress    @"enabled_validate_address_preference"
#define kPreferenceEnableValidatePhone      @"enabled_validate_phone_preference"
#define kPreferenceEnableValidateBirthday   @"enabled_validate_birthday_preference"

// Font
#define kFontHiraginoGothicW3               @"HiraKakuProN-W3"
#define kFontHiraginoGothicW6               @"HiraKakuProN-W6"
#define kFontHiraginoMorningW3              @"HiraMinProN-W3"
#define kFontHiraginoMorningW6              @"HiraMinProN-W6"
#define kFontOsaka                          @"Osaka"













