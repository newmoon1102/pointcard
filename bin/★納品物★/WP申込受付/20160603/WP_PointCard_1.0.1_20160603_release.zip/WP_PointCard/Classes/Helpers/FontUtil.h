//
//  FontUtil.h
//  SetaBase
//
//  Created by oa-center on 2015/01/16.
//  Copyright (c) 2015 oa-center company. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FontUtil : NSObject

+ (FontUtil *)sharedInstance;

+ (void)printAllSystemFonts;
+ (UIFont *)fontHelveticaNeue:(CGFloat)fontSize;
+ (UIFont *)fontHelveticaWithSize:(CGFloat)fontSize;
+ (UIFont *)fontHelveticaBoldObliqueWithSize:(CGFloat)fontSize;
+ (UIFont *)fontHelveticaBoldWithSize:(CGFloat)fontSize;
+ (UIFont *)fontHelveticaObliqueWithSize:(CGFloat)fontSize;
+ (UIFont *)fontHelveticaNeueMediume:(CGFloat)fontSize;
+ (UIFont *)fontHelveticaNeueRegular:(CGFloat)fontSize;
+ (UIFont *)fontHetiSCLight:(CGFloat)fontSize;
+ (UIFont *)fontHeitiSCMedium:(CGFloat)fontSize;
@end
