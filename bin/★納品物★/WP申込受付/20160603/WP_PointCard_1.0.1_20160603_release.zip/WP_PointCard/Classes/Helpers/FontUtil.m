//
//  FontUtil.m
//  SetaBase
//
//  Created by oa-center on 2015/01/16.
//  Copyright (c) 2015 oa-center company. All rights reserved.
//

#import "FontUtil.h"

@implementation FontUtil

+ (FontUtil *)sharedInstance {
    DEFINE_SHARED_INSTANCE_USING_BLOCK(^{
        return [[self alloc] init];
    });
}

+ (void)printAllSystemFonts
{
    printf("--------------------------------------------------------------------\n");
    NSArray *familyNames = [UIFont familyNames];
    for( NSString *familyName in familyNames ){
        printf( "Family: %s \n", [familyName UTF8String] );
        NSArray *fontNames = [UIFont fontNamesForFamilyName:familyName];
        for( NSString *fontName in fontNames ){
            printf( "\tFont: %s \n", [fontName UTF8String] );
        }
    }
    printf("--------------------------------------------------------------------\n");
}

+ (UIFont *)fontHetiSCLight:(CGFloat)fontSize
{
    return [UIFont fontWithName:@"STHeitiSC-Light" size:fontSize];
}
+ (UIFont *)fontHeitiSCMedium:(CGFloat)fontSize
{
    return [UIFont fontWithName:@"STHeitiSC-Medium" size:fontSize];
}

+ (UIFont *)fontHelveticaNeue:(CGFloat)fontSize
{
    return [UIFont fontWithName:@"Helvetica Neue" size:fontSize];
}
+ (UIFont *)fontHelveticaWithSize:(CGFloat)fontSize
{
    return [UIFont fontWithName:@"Helvetica" size:fontSize];
}

+ (UIFont *)fontHelveticaBoldObliqueWithSize:(CGFloat)fontSize
{
    return [UIFont fontWithName:@"Helvetica-BoldOblique" size:fontSize];
}

+ (UIFont *)fontHelveticaNeueMediume:(CGFloat)fontSize
{
    return [UIFont fontWithName:@"HelveticaNeue-Medium" size:fontSize];
}
+ (UIFont *)fontHelveticaNeueRegular:(CGFloat)fontSize
{
    return [UIFont fontWithName:@"HelveticaNeue-Regular" size:fontSize];
}
+ (UIFont *)fontHelveticaBoldWithSize:(CGFloat)fontSize
{
    return [UIFont fontWithName:@"Helvetica-Bold" size:fontSize];
}

+ (UIFont *)fontHelveticaObliqueWithSize:(CGFloat)fontSize
{
    return [UIFont fontWithName:@"Helvetica-Oblique" size:fontSize];
}

@end
