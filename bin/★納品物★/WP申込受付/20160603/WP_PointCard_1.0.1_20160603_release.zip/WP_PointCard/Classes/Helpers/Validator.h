//
//  Validator.h
//  Created by oa-center on 2015/01/16.
//  Copyright (c) 2015 oa-center company. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Validator : NSObject

+ (Validator *)sharedInstance;

+ (BOOL)validateEmail:(NSString*)email;
+ (BOOL)validateUrl:(NSString *)candidate;

+ (NSString *)getString:(NSInteger)i;
+ (NSNumber *)getSafeInt:(id)obj;
+ (NSNumber *)getSafeFloat:(id)obj;
+ (NSNumber *)getSafeBool:(id)obj;
+ (NSString *)getSafeString:(id)obj;
+ (BOOL)isNullOrNilObject:(id)object;
+ (BOOL)isValidObject:(id)object;

+ (BOOL)isContainsSpecialChar:(NSString *)theString;
+ (BOOL)isTheStringDate:(NSString*)theString;
+ (BOOL)isContainsEmoji:(NSString *)string;
+ (BOOL)isZeroAtFirstCharacter:(NSString *)string;
+ (BOOL)isCorrectString:(NSString *)string;
+ (BOOL)isCorrectPass:(NSString *)string;
+ (BOOL)isHiraganaString:(NSString *)strValidate;
+ (BOOL)isKanjiString:(NSString *)strValidate;
+ (BOOL)isAllHalfWidthCharacter:(NSString *)string;

@end
