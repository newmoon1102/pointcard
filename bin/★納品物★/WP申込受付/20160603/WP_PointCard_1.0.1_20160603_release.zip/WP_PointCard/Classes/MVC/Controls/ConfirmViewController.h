//
//  ConfirmViewController.h
//  WP_PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/02.
//  Copyright © 2016年 OA-Center Company. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConfirmViewController : UIViewController

@end
