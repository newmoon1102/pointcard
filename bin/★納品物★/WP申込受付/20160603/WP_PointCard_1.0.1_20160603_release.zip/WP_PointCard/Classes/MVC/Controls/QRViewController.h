//
//  QRViewController.h
//  WP_PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/11.
//  Copyright © 2016年 OA-Center Company. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "MBProgressHUD.h"
@interface QRViewController : UIViewController <AVCaptureMetadataOutputObjectsDelegate, UIAlertViewDelegate>
@property (weak, nonatomic) IBOutlet UIView *viewScanQRcode;
@end
