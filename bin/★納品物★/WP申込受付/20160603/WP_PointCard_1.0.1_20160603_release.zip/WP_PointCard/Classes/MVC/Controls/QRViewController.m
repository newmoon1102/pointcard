//
//  QRViewController.m
//  WP_PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/11.
//  Copyright © 2016年 OA-Center Company. All rights reserved.
//

#import "QRViewController.h"
#import "TopViewController.h"
#import "RegisterViewController.h"

@interface QRViewController ()

@property (nonatomic, strong) AVCaptureSession *captureSession;
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *videoPreviewLayer;

@property (strong, nonatomic) IBOutlet UILabel *lbRestaurantName;
@property (strong, nonatomic) IBOutlet UILabel *lbUrlWaitingPass;

@end

@implementation QRViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _captureSession = nil;
    self.lbRestaurantName.text = [Util objectForKey:kPreferenceCardName];
    self.lbUrlWaitingPass.text = [NSString stringWithFormat:@"%@%@%@",kFirstUrlWaitingPass,[Util objectForKey:kPreferenceMaimonSushi],kLastUrlWaitingPass];
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self startReading];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [self stopReading];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnBackTopClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    [self presentTopViewController];
}
- (void)presentTopViewController
{
    TopViewController *topVC = [[TopViewController alloc] initWithNibName:NibTopVC bundle:nil];
    [Util appDelegate].window.rootViewController = topVC;
}

#pragma mark - Private method implementation
- (BOOL)startReading {
    NSError *error;
    NSArray *videoDevices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    AVCaptureDevice *captureDevice = nil;
    for (AVCaptureDevice *device in videoDevices)
    {
        if (device.position == AVCaptureDevicePositionFront)
        {
            captureDevice = device;
            break;
        }
    }
    if (!captureDevice)
    {
        captureDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    }
    
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:captureDevice error:&error];
    
    if (!input) {
        NSLog(@"%@", [error localizedDescription]);
        return NO;
    }
    
    _captureSession = [[AVCaptureSession alloc] init];
    [_captureSession addInput:input];
    AVCaptureMetadataOutput *captureMetadataOutput = [[AVCaptureMetadataOutput alloc] init];
    [_captureSession addOutput:captureMetadataOutput];
    
    dispatch_queue_t dispatchQueue;
    dispatchQueue = dispatch_queue_create("myQueue", NULL);
    [captureMetadataOutput setMetadataObjectsDelegate:self queue:dispatchQueue];
    [captureMetadataOutput setMetadataObjectTypes:[NSArray arrayWithObject:AVMetadataObjectTypeQRCode]];
    
    _videoPreviewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:_captureSession];
    [_videoPreviewLayer setVideoGravity:AVLayerVideoGravityResizeAspectFill];
    [_videoPreviewLayer setFrame:_viewScanQRcode.layer.bounds];
    _videoPreviewLayer.connection.videoOrientation = AVCaptureVideoOrientationPortraitUpsideDown;
    [_viewScanQRcode.layer addSublayer:_videoPreviewLayer];
    
    [_captureSession startRunning];
    return YES;
}

-(void)stopReading{
    [_captureSession stopRunning];
    _captureSession = nil;
    
    [_videoPreviewLayer removeFromSuperlayer];
}

- (void)getUserInfoWithQrCode:(NSString *)qrCode
{
    NSString *shopAuthCode = [Util objectForKey:kDataUserDefaultShopAuthCode];
    __block id copy_self = self;
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDAnimationFade;
    hud.labelText = LB_MB_AUTHO_QR;
    
    [[APIClient wpSharedClient] getUserInfoWithShopAuthCode:shopAuthCode qrCode:qrCode completion:^(ResponseObject *obj) {
        [hud hide:YES];
        if (obj.statusCode == status_api_wp_ok) {
            [copy_self storeDataToUserDefault:obj.data];
        }else
        {
            [copy_self processErrorCode:obj.statusCode];
        }
    }];
}
- (void)storeDataToUserDefault:(NSDictionary *)dict
{
    NSString *strPointCard = [Util validateString:dict[kJsonCardNo]];
    if (![strPointCard isEqualToString:K_STRING_EMPTY]) {
        NSMutableString *strCardNumber = [NSMutableString stringWithString:strPointCard];
        if ([strCardNumber length] > 4) {
            [strCardNumber insertString:@"-" atIndex:4];
            NSString *msg = [NSString stringWithFormat:@"%@%@%@",ALERT_FIRST_MSG_CARD_NUM_EXIST,strCardNumber,ALERT_LAST_MSG_CARD_NUM_EXIST];
            [Util showMessage:msg withTitle:LB_ALERT_TITLE_CARD_NUM_EXIST];
        }else
        {
            NSString *msg = [NSString stringWithFormat:@"%@%@%@",ALERT_FIRST_MSG_CARD_NUM_EXIST,strCardNumber,ALERT_LAST_MSG_CARD_NUM_EXIST];
            [Util showMessage:msg withTitle:LB_ALERT_TITLE_CARD_NUM_EXIST];
        }
        return;
    }
    
    [Util setObject:[Util validateString:dict[kJsonMemberId]] forKey:kDataMemberId];
    [Util setObject:[Util validateString:dict[kJsonFirstNameKanji]] forKey:kDataFirstNameKanji];
    [Util setObject:[Util validateString:dict[kJsonLastNameKanji]] forKey:kDataLastNameKanji];
    [Util setObject:[Util validateString:dict[kJsonFirstNameKana]] forKey:kDataFirstNameHiragana];
    [Util setObject:[Util validateString:dict[kJsonLastNameKana]] forKey:kDataLastNameHiragana];
    [Util setObject:[Util validateString:dict[kJsonNameYobidashi]] forKey:kDataNameYobidashi];
    [Util setObject:[Util validateString:dict[kJsonFirstPostNumber]] forKey:kDataFirstPostNumber];
    [Util setObject:[Util validateString:dict[kJsonLastPostNumber]] forKey:kDataLastPostNumber];
    [Util setObject:[Util validateString:dict[kJsonPrefName]] forKey:kDataPrefectureName];
    [Util setObject:[Util validateString:dict[kJsonCityName]] forKey:kDataCityName];
    [Util setObject:[Util validateString:dict[kJsonTownName]] forKey:kDataTownName];
    [Util setObject:[Util validateString:dict[kJsonAreaName]] forKey:kDataAreaName];
    [Util setObject:[Util validateString:dict[@"bulding"]] forKey:kDataBuildingName]; // WI wrong
    [Util setObject:[Util validateString:dict[kJsonFirstTelNumber]] forKey:kDataFirstHomePhoneNumber];
    [Util setObject:[Util validateString:dict[kJsonMidTelNumber]] forKey:kDataMidHomePhoneNumber];
    [Util setObject:[Util validateString:dict[kJsonLastTelNumber]] forKey:kDataLastHomePhoneNumber];
    [Util setObject:[Util validateString:dict[kJsonFirstMobileNumber]] forKey:kDataFirstMobilePhoneNumber];
    [Util setObject:[Util validateString:dict[kJsonMidMobileNumber]] forKey:kDataMidMobilePhoneNumber];
    [Util setObject:[Util validateString:dict[kJsonLastMobileNumber]] forKey:kDataLastMobilePhoneNumber];
    [Util setObject:[Util validateString:dict[kJsonFirstOtherTelNumber]] forKey:kDataFirstOtherTelNumber];
    [Util setObject:[Util validateString:dict[kJsonMidOtherTelNumber]] forKey:kDataMidOtherTelNumber];
    [Util setObject:[Util validateString:dict[kJsonLastOtherTelNumber]] forKey:kDataLastOtherTelNumber];
    
    NSString *birthDay = [Util validateString:dict[kJsonBirthDay]];
    NSArray *arrDate = [birthDay componentsSeparatedByString:@"-"];
    if ([arrDate count] >= 3) {
        [Util setObject:[arrDate objectAtIndex:0] forKey:kDataYearBirthday];
        [Util setObject:[arrDate objectAtIndex:1] forKey:kDataMonthBirthday];
        [Util setObject:[arrDate objectAtIndex:2] forKey:kDataDayBirthday];
    }

    NSString *emailAddress = [Util validateString:dict[kJsonEmailAddress]];
    NSArray *arrEmail = [emailAddress componentsSeparatedByString:@"@"];
    if ([arrEmail count] >= 2) {
        [Util setObject:[arrEmail objectAtIndex:0] forKey:kDataFirstEmail];
        [Util setObject:[arrEmail objectAtIndex:1] forKey:kDataLastEmail];
    }

    [Util setObject:@"" forKey:kDataPassWord];
    
    [Util setObject:[NSNumber numberWithInteger:[Util validateInteger:dict[kJsonGender]]] forKey:kDataGender];
    NSInteger magaEmail = [Util validateInteger:dict[kJsonSendMaganizeMail]];
    if (magaEmail == 2) {
        [Util setObject:[NSNumber numberWithBool:YES] forKey:kDataAllowSendMagazineEmail];
    }else
    {
        [Util setObject:[NSNumber numberWithBool:NO] forKey:kDataAllowSendMagazineEmail];
    }
    NSInteger directEmail = [Util validateInteger:dict[kJsonSendDirectMail]];
    if (directEmail == 2) {
        [Util setObject:[NSNumber numberWithBool:YES] forKey:kDataAllowSendDirectEmail];
    }else
    {
        [Util setObject:[NSNumber numberWithBool:NO] forKey:kDataAllowSendDirectEmail];
    }
    [self presentRegisterViewController];
}
- (void)presentRegisterViewController
{
    RegisterViewController *registerVC = [[RegisterViewController alloc] initWithNibName:NibRegisterQRVC bundle:nil];
    [Util appDelegate].window.rootViewController = registerVC;
}

#pragma mark ----- AVCaptureMetadataOutputObjectsDelegate -----
-(void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection{
    
    if (metadataObjects != nil && [metadataObjects count] > 0) {
        AVMetadataMachineReadableCodeObject *metadataObj = [metadataObjects objectAtIndex:0];
        if ([[metadataObj type] isEqualToString:AVMetadataObjectTypeQRCode]) {
            [self performSelectorOnMainThread:@selector(stopReading) withObject:nil waitUntilDone:NO];
            [self performSelectorOnMainThread:@selector(getUserInfoWithQrCode:) withObject:[metadataObj stringValue] waitUntilDone:NO];
            [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundScanQR];
        }
    }
}
#pragma mark ----- UIAlertViewDelegate -----
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    if (buttonIndex == 1) {
        if (alertView.tag == 1) {
            [self startReading];
        }
    }
}
#pragma mark ----- Process Error -----
- (void)processErrorCode:(NSInteger)code{
    NSString *msg = nil;
    if (code == status_api_wp_no_data) {
        msg = ALERT_MSG_QR_CODE_ERR;
        [Util showMessage:msg
                withTitle:LB_ALERT_TITLE_ERR
        cancelButtonTitle:LB_ALERT_BTN_CANCEL
        otherButtonTitles:LB_ALERT_BTN_OK
                 delegate:self andTag:1];
    }else
    {
        msg = [APIClient errorCodeMessageWithCode:code];
        if (msg != nil) {
            [Util showMessage:msg withTitle:LB_ALERT_TITLE_ERR];
        }
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
