//
//  RegisterViewController.h
//  WP_PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/02.
//  Copyright © 2016年 OA-Center Company. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PopoverDate.h"
@interface RegisterViewController : UIViewController<UITextFieldDelegate,UIAlertViewDelegate, PopoverDateDelegate,NSXMLParserDelegate>
@property (strong, nonatomic) IBOutlet UILabel *lbRestaurantName;
@property (strong, nonatomic) IBOutlet UILabel *lbPrefecturesName;
@property (strong, nonatomic) IBOutlet UILabel *lbSelectYearBirthday;
@property (strong, nonatomic) IBOutlet UILabel *lbSelectMonthBirthday;
@property (strong, nonatomic) IBOutlet UILabel *lbSelectDayBirthday;
@property (strong, nonatomic) IBOutlet UILabel *lbSelectMagazineMail;
@property (strong, nonatomic) IBOutlet UILabel *lbSelectDirectMail;

@property (strong, nonatomic) IBOutlet UITextField *txtFieldFirstNameKanji;
@property (strong, nonatomic) IBOutlet UITextField *txtFieldLastNameKanji;
@property (strong, nonatomic) IBOutlet UITextField *txtFieldFirstNameHiragana;
@property (strong, nonatomic) IBOutlet UITextField *txtFieldLastNameHiragana;
@property (strong, nonatomic) IBOutlet UITextField *txtFieldNameYobidashi;

@property (strong, nonatomic) IBOutlet UITextField *txtFieldFirstPostNumber;
@property (strong, nonatomic) IBOutlet UITextField *txtFieldLastPostNumber;

@property (strong, nonatomic) IBOutlet UITextField *txtFieldCityName;

@property (strong, nonatomic) IBOutlet UITextField *txtFieldTownName;
@property (strong, nonatomic) IBOutlet UITextField *txtFieldAreaName;

@property (strong, nonatomic) IBOutlet UITextField *txtFieldBuildingName;

@property (strong, nonatomic) IBOutlet UITextField *txtFieldFirstPhoneNumber;
@property (strong, nonatomic) IBOutlet UITextField *txtFieldMidPhoneNumber;
@property (strong, nonatomic) IBOutlet UITextField *txtFieldLastPhoneNumber;

@property (strong, nonatomic) IBOutlet UITextField *txtFieldFirstMobileNumber;
@property (strong, nonatomic) IBOutlet UITextField *txtFieldMidMobileNumber;
@property (strong, nonatomic) IBOutlet UITextField *txtFieldLastMobileNumber;

@property (strong, nonatomic) IBOutlet UITextField *txtFieldFirstMail;
@property (strong, nonatomic) IBOutlet UITextField *txtFieldLastMail;

@property (strong, nonatomic) IBOutlet UITextField *txtFieldPassword;

@property (strong, nonatomic) IBOutlet UIButton *btnMale;
@property (strong, nonatomic) IBOutlet UIButton *btnFemale;
@property (strong, nonatomic) IBOutlet UIButton *btnMagazineEmail;
@property (strong, nonatomic) IBOutlet UIButton *btnDirectEmail;

@property (strong, nonatomic) IBOutlet UIView *vRegister;
@property (nonatomic, strong) PopoverDate           *popoverDate;
@property (nonatomic, strong) UIPopoverController   *popoverDateController;
@end
