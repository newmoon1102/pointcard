//
//  SetupPrinterViewController.h
//  PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/13.
//  Copyright (c) 2016年 OA-Center Company. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetupPrinterViewController : UIViewController<UITableViewDataSource, UITableViewDelegate,Epos2DiscoveryDelegate,Epos2PtrReceiveDelegate>
{
    Epos2FilterOption *filteroption_;
    NSMutableArray *printerList_;
}
@property (weak, nonatomic) IBOutlet UIButton *buttonRestart;
@property(weak, nonatomic) IBOutlet UITableView *printerView_;
@end
