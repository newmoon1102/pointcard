//
//  TopViewController.m
//  WP_PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/02.
//  Copyright © 2016年 OA-Center Company. All rights reserved.
//

#import "TopViewController.h"
#import "RegisterViewController.h"
#import "LoginViewController.h"
#import "QRViewController.h"

@interface TopViewController ()
@property (strong, nonatomic) IBOutlet UILabel *lbRestaurantName;
@property (strong, nonatomic) IBOutlet UILabel *lbApplicationName;
@property (strong, nonatomic) IBOutlet UIButton *btnBackLogin;

@end

@implementation TopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
    longPress.minimumPressDuration = TIME_DURATION_LONG_PRESS_GESTURE;
    longPress.delegate = self;
    [self.btnBackLogin addGestureRecognizer:longPress];
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.lbRestaurantName.text = [Util objectForKey:kPreferenceCardName];
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self resetUserInfo];
}
#pragma mark ----- Gesture Recognizer Delegate -----
- (void)handleLongPress:(UILongPressGestureRecognizer*)sender {
    if (sender.state == UIGestureRecognizerStateBegan){
        [Util showMessage:LB_ALERT_MSG_BACK_LOGIN
                withTitle:LB_ALERT_TITLE_CONFIRM
        cancelButtonTitle:LB_ALERT_BTN_CANCEL
        otherButtonTitles:LB_ALERT_BTN_OK
                 delegate:self andTag:1];
        
    }
}
#pragma mark ----- UIAlertViewDelegate -----
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    if (buttonIndex == 1) {
        if (alertView.tag == 1) {
            LoginViewController *loginVC = [[LoginViewController alloc] initWithNibName:NibLoginVC bundle:nil];
            [Util appDelegate].window.rootViewController = loginVC;
        }
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnNewMemberClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    [Util setObject:@(NEW_MEMBER) forKey:kDataUserDefaultMemberType];
    RegisterViewController *registerVC = [[RegisterViewController alloc] initWithNibName:NibRegisterVC bundle:nil];
    [Util appDelegate].window.rootViewController = registerVC;
}
- (IBAction)btnAddMemberClick:(id)sender {
    [[AudioPlayerManager shareAudioManager] playEffectAudio:kSoundButton];
    [Util setObject:@(OLD_MEMBER) forKey:kDataUserDefaultMemberType];
    QRViewController *qrVC = [[QRViewController alloc] initWithNibName:NibQRVC bundle:nil];
    [Util appDelegate].window.rootViewController = qrVC;
}

- (void)resetUserInfo
{
    [Util setObject:@"" forKey:kDataMemberId];
    [Util setObject:@"" forKey:kDataFirstNameKanji];
    [Util setObject:@"" forKey:kDataLastNameKanji];
    [Util setObject:@"" forKey:kDataFirstNameHiragana];
    [Util setObject:@"" forKey:kDataLastNameHiragana];
    [Util setObject:@"" forKey:kDataNameYobidashi];
    [Util setObject:@"" forKey:kDataFirstPostNumber];
    [Util setObject:@"" forKey:kDataLastPostNumber];
    [Util setObject:@"" forKey:kDataPrefectureName];
    [Util setObject:@"" forKey:kDataCityName];
    [Util setObject:@"" forKey:kDataTownName];
    [Util setObject:@"" forKey:kDataAreaName];
    [Util setObject:@"" forKey:kDataBuildingName];
    [Util setObject:@"" forKey:kDataFirstHomePhoneNumber];
    [Util setObject:@"" forKey:kDataMidHomePhoneNumber];
    [Util setObject:@"" forKey:kDataLastHomePhoneNumber];
    [Util setObject:@"" forKey:kDataFirstMobilePhoneNumber];
    [Util setObject:@"" forKey:kDataMidMobilePhoneNumber];
    [Util setObject:@"" forKey:kDataLastMobilePhoneNumber];
    [Util setObject:@"" forKey:kDataFirstOtherTelNumber];
    [Util setObject:@"" forKey:kDataMidOtherTelNumber];
    [Util setObject:@"" forKey:kDataLastOtherTelNumber];
    [Util setObject:@"" forKey:kDataYearBirthday];
    [Util setObject:@"" forKey:kDataMonthBirthday];
    [Util setObject:@"" forKey:kDataDayBirthday];
    [Util setObject:[NSNumber numberWithInteger:1] forKey:kDataGender];
    [Util setObject:@"" forKey:kDataFirstEmail];
    [Util setObject:@"" forKey:kDataLastEmail];
    [Util setObject:@"" forKey:kDataPassWord];
    [Util setObject:[NSNumber numberWithBool:YES] forKey:kDataAllowSendMagazineEmail];
    [Util setObject:[NSNumber numberWithBool:YES] forKey:kDataAllowSendDirectEmail];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
