//
//  PopoverDate.h
//  WP_PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/10.
//  Copyright © 2016年 OA-Center Company. All rights reserved.
//

#import <UIKit/UIKit.h>
@class PopoverDate;

@protocol PopoverDateDelegate <NSObject>
@required
-(void)selectedValue:(int)newValue withMode:(SELECT_POPOVER)mode;
-(void)selectedProvince:(NSString *)newValue;
@end

@interface PopoverDate : UITableViewController
@property (assign, nonatomic) SELECT_POPOVER selectMode;
@property (nonatomic, strong) NSMutableArray *arrValues;
@property (nonatomic, weak) id<PopoverDateDelegate> delegate;
@property (nonatomic, assign) NSInteger txtFieldTag;

@end
