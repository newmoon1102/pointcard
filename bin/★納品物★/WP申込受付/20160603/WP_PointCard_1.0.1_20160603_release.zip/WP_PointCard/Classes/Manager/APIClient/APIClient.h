//
//  APIClient.h
//  PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/13.
//  Copyright (c) 2016年 OA-Center Company. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFHTTPClient.h"
#import "AFImageRequestOperation.h"
#import "ResponseObject.h"

typedef  void (^ApiCompletion)(ResponseObject *obj);

@interface APIClient : AFHTTPClient

+ (APIClient *)wpSharedClient;
+ (APIClient *)registerSharedClient;
+ (APIClient *)wpGetAddressSharedClient;

+ (void)destroySharedClient;
+ (NSString *)errorCodeMessageWithCode:(NSInteger)status;

// Login and get data from WPサーバー
- (void)login:(NSString *)userID password:(NSString *)pw completion:(ApiCompletion)block;
- (void)getUserInfoWithShopAuthCode:(NSString *)shopAuthCode qrCode:(NSString *)qrCode completion:(ApiCompletion)block;
- (void)checkExistEmailWithShopAuthCode:(NSString *)shopAuthCode email:(NSString *)email completion:(ApiCompletion)block;

- (void)getAddressByZipCode:(NSString *)zipCode completion:(ApiCompletion)block;
// Send data to 申込受付サーバー
- (void)sendData:(NSString *)strJson completion:(ApiCompletion)block;
@end
