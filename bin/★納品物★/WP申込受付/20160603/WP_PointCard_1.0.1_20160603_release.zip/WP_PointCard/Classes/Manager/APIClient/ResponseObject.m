//
//  ResponseObject.m
//  PointCard
//
//  Created by 株式会社OA推進センター on 2016/05/13.
//  Copyright (c) 2016年 OA-Center Company. All rights reserved.
//

#import "ResponseObject.h"

@implementation ResponseObject
- (id)init{
    if (self = [super init]) {
    }
    return self;
}
@end
